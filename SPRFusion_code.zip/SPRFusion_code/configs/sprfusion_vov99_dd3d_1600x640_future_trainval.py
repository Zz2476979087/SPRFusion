import torch
pi = torch.pi

dataset_type = 'CustomNuScenesDataset_radar'
dataset_root = 'data/nuscenes/'

input_modality = dict(
    use_lidar=False,
    use_camera=True,
    use_radar=True,
    use_map=False,
    use_external=True
)

class_names = [
    'car', 'truck', 'trailer', 'bus', 'construction_vehicle', 'bicycle',
    'motorcycle', 'pedestrian', 'traffic_cone', 'barrier'
]

point_cloud_range = [-51.2, -51.2, -5.0, 51.2, 51.2, 3.0]
voxel_size = [0.2, 0.2, 8]

# arch config
embed_dims = 256
num_layers = 6

# 1 current + 6 past + 4 future = 11 frames (paper uses +6 future; reduced to fit bs=2 w/o grad accum)
num_frames_prev = 6
num_frames_next = 3
num_frames = 1 + num_frames_prev + num_frames_next  # 11

num_levels = 4
num_points = 4
num_points_bev = 4
img_depth_num = 3

bev_depth_num = 5

d_region_list = [0.08, 0.07, 0.06, 0.05, 0.04, 0.03]

num_clusters = 6
num_ray = 150
num_query = num_ray * num_clusters  # 900

# V2-99 test set: 640x1600 resolution (Paper Table 2, Supp. Table 1)
ida_aug_conf = {
    'resize_lim': (1.0, 1.0),
    'final_dim': (640, 1600),
    'bot_pct_lim': (0.0, 0.0),
    'rot_lim': (0.0, 0.0),
    'H': 900, 'W': 1600,
    'rand_flip': True,
}

grid_config = {
    'x': [-51.2, 51.2, 0.8],
    'y': [-51.2, 51.2, 0.8],
    'z': [-5, 3, 8],
    'depth': [1.0, 65.0, 96.0],
    'rcs': [-64, 64, 64]
}

numC_Trans = 256
file_client_args = dict(backend='disk')

# VoVNet-99 backbone (DD3D pretrained)
img_backbone = dict(
    type='VoVNet',
    spec_name='V-99-eSE',
    out_features=['stage2', 'stage3', 'stage4', 'stage5'],
    frozen_stages=1,
    norm_eval=True,
    with_cp=True)

img_neck = dict(
    type='FPN',
    in_channels=[256, 512, 768, 1024],
    out_channels=embed_dims,
    num_outs=num_levels)

img_norm_cfg = dict(
    mean=[123.675, 116.280, 103.530],
    std=[58.395, 57.120, 57.375],
    to_rgb=True)

img_lss_neck = dict(
    type='CustomFPN',
    in_channels=[768, 1024],
    out_channels=256,
    num_outs=1,
    start_level=0,
    out_ids=[0])

img_lss_view_transformer = dict(
    type='LSSViewTransformerBEVDepth_sprfusion',
    grid_config=grid_config,
    input_size=ida_aug_conf['final_dim'],
    in_channels=256,
    out_channels=numC_Trans,
    depthnet_cfg=dict(use_dcn=False),
    downsample=16,
    loss_depth_weight=2.0)

pre_process = None
model = dict(
    type='SPRFusion',
    img_backbone_chunk_size=6,
    data_aug=dict(
        img_color_aug=True,
        img_norm_cfg=img_norm_cfg,
        img_pad_cfg=dict(size_divisor=32)),
    stop_prev_grad=0,
    img_backbone=img_backbone,
    img_neck=img_neck,
    img_lss_neck=img_lss_neck,
    img_lss_view_transformer=img_lss_view_transformer,
    num_lss_fpn=2,
    dep_downsample=16,
    pre_process=pre_process,
    radar_voxel_layer=dict(
        max_num_points=10,
        voxel_size=[0.8, 0.8, 8],
        max_voxels=(30000, 40000),
        point_cloud_range=point_cloud_range,
        deterministic=False,),

    radar_voxel_encoder=dict(
        type='PillarFeatureNet',
        in_channels=7,
        feat_channels=[64],
        with_distance=False,
        voxel_size=[0.8, 0.8, 8],
        norm_cfg=dict(type='BN1d', eps=1e-3, momentum=0.01),
        legacy=False),

    radar_middle_encoder=dict(
        type='PointPillarsScatter', in_channels=64, output_shape=(128, 128)),

    pts_bbox_head=dict(
        type='SPRFusion_head',
        num_classes=10,
        num_clusters=num_clusters,
        in_channels=embed_dims,
        num_query=num_query,
        query_denoising=True,
        query_denoising_groups=10,
        code_size=10,
        code_weights=[2.0, 2.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
        sync_cls_avg_factor=True,
        transformer=dict(
            type='SPRFusionTransformer',
            embed_dims=embed_dims,
            num_frames=num_frames,
            num_points=num_points,
            num_points_bev=num_points_bev,
            img_depth_num=img_depth_num,
            bev_depth_num=bev_depth_num,
            num_layers=num_layers,
            num_levels=num_levels,
            num_ray=num_ray,
            num_classes=10,
            code_size=10,
            pc_range=point_cloud_range,
            d_region_list=d_region_list,
            lgsc_alpha=0.01,
            lgsc_prior_dim=64,
            codebook_path='assets/semantic_codebook_nuscenes.pt'),
        bbox_coder=dict(
            type='NMSFreeCoder',
            post_center_range=[-61.2, -61.2, -10.0, 61.2, 61.2, 10.0],
            pc_range=point_cloud_range,
            max_num=300,
            voxel_size=voxel_size,
            score_threshold=0.05,
            num_classes=10),
        positional_encoding=dict(
            type='SinePositionalEncoding',
            num_feats=embed_dims // 2,
            normalize=True,
            offset=-0.5),
        loss_cls=dict(
            type='FocalLoss',
            use_sigmoid=True,
            gamma=2.0,
            alpha=0.25,
            loss_weight=2.0),
        loss_bbox=dict(type='L1Loss', loss_weight=0.25),
        loss_iou=dict(type='GIoULoss', loss_weight=0.0)),
    train_cfg=dict(pts=dict(
        grid_size=[512, 512, 1],
        voxel_size=voxel_size,
        point_cloud_range=point_cloud_range,
        out_size_factor=4,
        assigner=dict(
            type='PolarHungarianAssigner3D',
            cls_cost=dict(type='FocalLossCost', weight=2.0),
            reg_cost=dict(type='BBox3DL1Cost', weight=0.25),
            theta_cost=dict(type='ThetaL1Cost', weight=3.0),
            iou_cost=dict(type='IoUCost', weight=0.0),
        )
    ))
)

# Pipeline uses future frames
train_pipeline = [
    dict(type='LoadMultiViewImageFromFiles', to_float32=False, color_type='color'),
    dict(type='LoadMultiViewImageFromMultiSweepsFuture',
         prev_sweeps_num=num_frames_prev, next_sweeps_num=num_frames_next),
    dict(type='LoadAnnotations3D', with_bbox_3d=True, with_label_3d=True, with_attr_label=False,
        with_label=False, with_bbox_depth=False),
    dict(type='ObjectRangeFilter', point_cloud_range=point_cloud_range),
    dict(type='ObjectNameFilter', classes=class_names),
    dict(type='RandomTransformImage', ida_aug_conf=ida_aug_conf, training=True),
    dict(type='Loadnuradarpoints', coord_type='RADAR', num_sweeps=5, file_client_args=file_client_args),
    dict(type='LoadradarpointsFromMultiSweepsFuture',
         prev_sweeps_num=num_frames_prev, next_sweeps_num=num_frames_next,
         num_aggr_sweeps=5, test_mode=False),
    dict(type='LoadPointsFromFile', coord_type='LIDAR', load_dim=5, use_dim=5, file_client_args=file_client_args),
    dict(type='SPRGlobalRotScaleTransImage', rot_range=[-0.3925, 0.3925], scale_ratio_range=[0.95, 1.05]),
    dict(type='PointToMultiViewDepth', downsample=1, grid_config=grid_config),
    dict(type='RadarPointToMultiViewDepth', downsample=1, grid_config=grid_config, test_mode=False),
    dict(type='SPRFormatBundle3D', class_names=class_names),
    dict(type='Collect3D', keys=['gt_bboxes_3d', 'gt_labels_3d', 'img', 'gt_depth', 'radar_depth', 'radar_rcs', 'radar_points'], meta_keys=(
        'filename', 'ori_shape', 'img_shape', 'pad_shape', 'lidar2img', 'img_timestamp', 'intrinsics'))
]

test_pipeline = [
    dict(type='LoadMultiViewImageFromFiles', to_float32=False, color_type='color'),
    dict(type='LoadMultiViewImageFromMultiSweepsFuture',
         prev_sweeps_num=num_frames_prev, next_sweeps_num=num_frames_next, test_mode=True),
    dict(type='RandomTransformImage', ida_aug_conf=ida_aug_conf, training=False),
    dict(type='Loadnuradarpoints', coord_type='RADAR', num_sweeps=5, file_client_args=file_client_args),
    dict(type='LoadradarpointsFromMultiSweepsFuture',
         prev_sweeps_num=num_frames_prev, next_sweeps_num=num_frames_next,
         num_aggr_sweeps=5, test_mode=True),
    dict(type='LoadPointsFromFile', coord_type='LIDAR', load_dim=5, use_dim=5, file_client_args=file_client_args),
    dict(type='PointToMultiViewDepth', downsample=1, grid_config=grid_config),
    dict(type='RadarPointToMultiViewDepth', downsample=1, grid_config=grid_config, test_mode=True),
    dict(
        type='MultiScaleFlipAug3D',
        img_scale=(1408, 512),
        pts_scale_ratio=1,
        flip=False,
        transforms=[
            dict(type='SPRFormatBundle3D', class_names=class_names, with_label=False),
            dict(type='Collect3D', keys=['img', 'gt_depth', 'radar_points', 'radar_depth', 'radar_rcs'], meta_keys=(
                'filename', 'box_type_3d', 'ori_shape', 'img_shape', 'pad_shape',
                'lidar2img', 'img_timestamp', 'intrinsics'))
        ])
]

# Test pipeline with use_test_nusc=True for test set radar loading
test_pipeline_testset = [
    dict(type='LoadMultiViewImageFromFiles', to_float32=False, color_type='color'),
    dict(type='LoadMultiViewImageFromMultiSweepsFuture',
         prev_sweeps_num=num_frames_prev, next_sweeps_num=num_frames_next, test_mode=True),
    dict(type='RandomTransformImage', ida_aug_conf=ida_aug_conf, training=False),
    dict(type='Loadnuradarpoints', coord_type='RADAR', num_sweeps=5, use_test_nusc=True, file_client_args=file_client_args),
    dict(type='LoadradarpointsFromMultiSweepsFuture',
         prev_sweeps_num=num_frames_prev, next_sweeps_num=num_frames_next,
         num_aggr_sweeps=5, test_mode=True, use_test_nusc=True),
    dict(type='LoadPointsFromFile', coord_type='LIDAR', load_dim=5, use_dim=5, file_client_args=file_client_args),
    dict(type='PointToMultiViewDepth', downsample=1, grid_config=grid_config),
    dict(type='RadarPointToMultiViewDepth', downsample=1, grid_config=grid_config, test_mode=True),
    dict(
        type='MultiScaleFlipAug3D',
        img_scale=(1408, 512),
        pts_scale_ratio=1,
        flip=False,
        transforms=[
            dict(type='SPRFormatBundle3D', class_names=class_names, with_label=False),
            dict(type='Collect3D', keys=['img', 'gt_depth', 'radar_points', 'radar_depth', 'radar_rcs'], meta_keys=(
                'filename', 'box_type_3d', 'ori_shape', 'img_shape', 'pad_shape',
                'lidar2img', 'img_timestamp', 'intrinsics'))
        ])
]

data = dict(
    workers_per_gpu=16,
    train=dict(
        type=dataset_type,
        data_root=dataset_root,
        ann_file=dataset_root + 'nuscenes_infos_trainval_sweep.pkl',
        pipeline=train_pipeline,
        classes=class_names,
        modality=input_modality,
        test_mode=False,
        use_valid_flag=True,
        box_type_3d='LiDAR'),
    val=dict(
        type=dataset_type,
        data_root=dataset_root,
        ann_file=dataset_root + 'nuscenes_infos_val_sweep.pkl',
        pipeline=test_pipeline,
        classes=class_names,
        modality=input_modality,
        test_mode=True,
        box_type_3d='LiDAR'),
    test=dict(
        type=dataset_type,
        data_root=dataset_root,
        ann_file=dataset_root + 'nuscenes_infos_test_sweep.pkl',
        pipeline=test_pipeline_testset,
        classes=class_names,
        modality=input_modality,
        test_mode=True,
        box_type_3d='LiDAR')
)

# Paper Sec.4.2 & Supp. Table 2: AdamW, base lr=4e-4, backbone lr_mult=0.1
# VoV99 test submission: 4 GPUs x bs=4 = global batch_size=16
optimizer = dict(
    type='AdamW',
    lr=4e-4,
    paramwise_cfg=dict(custom_keys={
        'img_backbone': dict(lr_mult=0.1),
        'sampling_offset': dict(lr_mult=0.1),
        'fusion': dict(lr_mult=0.5),
        'rgas': dict(lr_mult=0.1),
        'query_to_prior': dict(lr_mult=0.01),
        'prior_to_calib': dict(lr_mult=0.01),
        'lgsc_blend': dict(lr_mult=0.01),
        'cam_temporal_encoder': dict(lr_mult=0.5),
    }),
    weight_decay=0.01
)

optimizer_config = dict(
    type='Fp16OptimizerHook',
    loss_scale=512.0,
    grad_clip=dict(max_norm=35, norm_type=2),
)

lr_config = dict(
    policy='CosineAnnealing',
    warmup='linear',
    warmup_iters=500,
    warmup_ratio=1.0 / 3,
    min_lr_ratio=1e-3
)

total_epochs = 24
batch_size = 4

# V2-99 DD3D pretrained
load_from = 'pretrain/vov99_dd3d_1600x640_trainval_future.pth'
revise_keys = None

resume_from = None

default_hooks = dict(
    checkpoint=None
)

checkpoint_config = dict(interval=1, max_keep_ckpts=4)

log_config = dict(
    interval=1,
    hooks=[
        dict(type='MyTextLoggerHook', interval=50, reset_flag=True),
        dict(type='MyTensorboardLoggerHook', interval=500, reset_flag=True)
    ]
)

# Validate on val set every 2 epochs
eval_config = dict(interval=1)

debug = False

custom_hooks = [
    dict(
        type='SequentialControlHook',
        start_epoch=24,
    ),
    dict(
        type='MEGVIIEMAHook',
        init_updates=0,
        decay=0.9990,
        resume=None,
        interval=1,
    ),
]
