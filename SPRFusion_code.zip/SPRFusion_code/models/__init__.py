"""SPRFusion model package.

Registers all model components with mmdetection/mmdet3d registries.
"""
from .encoders import __all__ as _enc_all
from .detection import __all__ as _det_all
from .bev import __all__ as _bev_all
from .training_hooks import __all__ as _hook_all
from .common import __all__ as _common_all

from .detector import SPRFusion
from .head import SPRFusion_head
from .decoder import SPRFusionTransformer

__all__ = [
    'SPRFusion', 'SPRFusion_head', 'SPRFusionTransformer',
]
