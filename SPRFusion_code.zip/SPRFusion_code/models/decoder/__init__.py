"""SPRFusion decoder package.

Re-exports all decoder components for convenient imports.
"""
from .sprfusion_decoder import (
    SPRFusionTransformer,
    SPRFusionDecoder,
    SPRFusionDecoderLayer,
)
from .attention_modules import (
    ScaleAdaptiveSelfAttention,
    UncertaintyAwareCrossModalGatedFusion,
    ReliabilityAwareFeatureRectification,
)
from .adaptive_sampling import (
    SPRFusionSampling,
    BEVSampling,
    AdaptiveMixing,
)
from .temporal_alignment import (
    CrossModalTemporalBEVEncoder,
    RadarBEVTemporalEncoder,
    ConvGRU,
    ConvGRUCell,
)
from .semantic_calibration import (
    SemanticRadarGuidedCalibration,
    ReliabilityGuidedSamplingEnhancer,
)

__all__ = [
    'SPRFusionTransformer', 'SPRFusionDecoder', 'SPRFusionDecoderLayer',
    'ScaleAdaptiveSelfAttention',
    'UncertaintyAwareCrossModalGatedFusion', 'ReliabilityAwareFeatureRectification',
    'SPRFusionSampling', 'BEVSampling', 'AdaptiveMixing',
    'CrossModalTemporalBEVEncoder', 'RadarBEVTemporalEncoder', 'ConvGRU', 'ConvGRUCell',
    'SemanticRadarGuidedCalibration', 'ReliabilityGuidedSamplingEnhancer',
]
