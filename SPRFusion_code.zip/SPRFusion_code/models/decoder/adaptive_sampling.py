"""Adaptive spatio-temporal sampling modules for SPRFusion."""
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.runner import BaseModule
from mmcv.cnn.bricks.transformer import build_positional_encoding
from ..detection.utils import theta_d2xy_coods, xy2theta_d_coods, decode_bbox
from ..sampling.sparse_sampling import sampling_4d, make_sample_points
from ..sampling.bev_attention import BEVSelfAttention
from ..checkpoint import checkpoint as cp


class SPRFusionSampling(BaseModule):
    """Adaptive spatio-temporal image-view sampling (Section 3.3)."""
    def __init__(self, embed_dims=256, num_frames=4, num_groups=4,
                 num_points=8, num_levels=4, depth_num=15, pc_range=[], init_cfg=None):
        super().__init__(init_cfg)
        self.num_frames = num_frames
        self.num_points = num_points
        self.num_groups = num_groups
        self.num_levels = num_levels
        self.pc_range = pc_range
        self.depth_num = depth_num
        self.ray_points_offset = nn.Linear(embed_dims, self.depth_num)
        self.sampling_offset = nn.Linear(embed_dims, depth_num * num_groups * num_points * 3)
        self.scale_weights = nn.Linear(embed_dims, num_groups * num_frames * depth_num * num_points * num_levels)

    def init_weights(self):
        bias = self.sampling_offset.bias.data.view(self.depth_num * self.num_groups * self.num_points, 3)
        nn.init.zeros_(self.sampling_offset.weight)
        nn.init.uniform_(bias[:, 0:3], -0.5, 0.5)

    def inner_forward(self, query_ray, query_feat, mlvl_feats, img_metas, d_region=0.1):
        B, Q, M = query_ray.shape
        image_h, image_w, _ = img_metas[0]['img_shape'][0]
        query_bbox = theta_d2xy_coods(query_ray).clone()

        sampling_offset = self.sampling_offset(query_feat)
        sampling_offset = sampling_offset.view(B, Q, self.num_groups * self.num_points * self.depth_num, 3)
        sampling_points = make_sample_points(query_bbox, sampling_offset, self.pc_range)
        sampling_points = sampling_points.reshape(B, Q, 1, self.num_groups, self.num_points * self.depth_num, 3)
        sampling_points = sampling_points.expand(B, Q, self.num_frames, self.num_groups, self.num_points * self.depth_num, 3)

        time_diff = img_metas[0]['time_diff']
        time_diff = time_diff[:, None, :, None]
        vel = query_ray[..., 8:].detach()
        vel = vel[:, :, None, :]
        dist = vel * time_diff
        dist = dist[:, :, :, None, None, :]
        sampling_points = torch.cat([
            sampling_points[..., 0:2] - dist,
            sampling_points[..., 2:3]
        ], dim=-1)

        sampling_points[..., 0:1] = (sampling_points[..., 0:1] - self.pc_range[0]) / (self.pc_range[3] - self.pc_range[0])
        sampling_points[..., 1:2] = (sampling_points[..., 1:2] - self.pc_range[1]) / (self.pc_range[4] - self.pc_range[1])
        sampling_points = xy2theta_d_coods(sampling_points)
        sampling_points = sampling_points.reshape(B, Q, self.num_frames, self.num_groups, self.num_points, self.depth_num, 3)

        sampling_points_d = torch.linspace(-d_region, d_region, self.depth_num).view(1, 1, self.depth_num).repeat(B, Q, 1).to(query_bbox.device)
        sampling_points_d = sampling_points_d + (self.ray_points_offset(query_feat).sigmoid() * 2 - 1) * d_region / self.depth_num / 2
        sampling_points_d = sampling_points_d.view(B, Q, 1, 1, 1, self.depth_num, 1).repeat(1, 1, self.num_frames, self.num_groups, self.num_points, 1, 1)

        sampling_points = torch.cat((sampling_points[..., 0:1], sampling_points[..., 1:2] + sampling_points_d, sampling_points[..., 2:]), dim=-1)
        sampling_points = sampling_points.reshape(B, Q, self.num_frames, self.num_groups, self.num_points * self.depth_num, 3)
        sampling_points = theta_d2xy_coods(sampling_points)
        sampling_points[..., 0:1] = sampling_points[..., 0:1] * (self.pc_range[3] - self.pc_range[0]) + self.pc_range[0]
        sampling_points[..., 1:2] = sampling_points[..., 1:2] * (self.pc_range[4] - self.pc_range[1]) + self.pc_range[1]

        scale_weights = self.scale_weights(query_feat).view(B, Q, self.num_groups, self.num_frames, self.depth_num * self.num_points, self.num_levels).contiguous()
        scale_weights = torch.softmax(scale_weights, dim=-1)

        sampled_feats = sampling_4d(
            sampling_points, mlvl_feats, scale_weights,
            img_metas[0]['lidar2img'], image_h, image_w
        )
        return sampled_feats

    def forward(self, query_ray, query_feat, mlvl_feats, img_metas, d_region=0.1):
        if self.training and query_feat.requires_grad:
            return cp(self.inner_forward, query_ray, query_feat, mlvl_feats, img_metas, d_region=d_region, use_reentrant=False)
        else:
            return self.inner_forward(query_ray, query_feat, mlvl_feats, img_metas, d_region=d_region)

# Backward-compatible alias


class BEVSampling(BaseModule):
    """BEV feature sampling with temporal encoding."""
    def __init__(self, embed_dims=256, num_frames=4, num_points=8,
                 num_heads=4, num_levels=4, pc_range=[],
                 spatial_shapes=(128, 128), depth_num=30,
                 temp_radar=False, init_cfg=None):
        super().__init__(init_cfg)
        self.num_frames = num_frames
        self.num_points = num_points
        self.num_heads = num_heads
        self.num_levels = num_levels
        self.embed_dims = embed_dims
        self.pc_range = pc_range
        self.depth_num = depth_num

        self.ray_points_offset = nn.Linear(embed_dims, self.depth_num)
        self.sampling_offset = nn.Linear(embed_dims, depth_num * num_heads * num_points * 2)
        self.scale_weights = nn.Linear(embed_dims, num_heads * num_levels * depth_num * num_points)

        positional_encoding = dict(
            type='LearnedPositionalEncoding',
            num_feats=128,
            row_num_embed=spatial_shapes[1],
            col_num_embed=spatial_shapes[0])
        self.positional_encoding = build_positional_encoding(positional_encoding)
        self.attention = BEVSelfAttention(
            embed_dims=embed_dims, num_heads=4, num_levels=1,
            num_points=num_points * self.depth_num,
            num_bev_queue=num_frames, queue_weight=True)
        self.temp_radar = temp_radar
        if temp_radar:
            from .temporal_alignment import RadarBEVTemporalEncoder
            self.temporal_encoder = RadarBEVTemporalEncoder(embed_dims, 64, num_frames)

    def init_weights(self):
        bias = self.sampling_offset.bias.data.view(self.depth_num * self.num_heads * self.num_points, 2)
        nn.init.zeros_(self.sampling_offset.weight)
        nn.init.uniform_(bias[:, 0:2], -0.5, 0.5)
        self.attention.init_weights()
        if self.temp_radar:
            self.temporal_encoder.init_weights()

    def inner_forward(self, query_ray, query_feat, bev_feats, img_metas, d_region=0.1):
        if self.temp_radar:
            bev_feats = self.temporal_encoder(bev_feats)
        B, Q, M = query_ray.shape
        bev_h, bev_w = bev_feats.shape[-2:]
        query_bbox = theta_d2xy_coods(query_ray).clone()

        sampling_offset = self.sampling_offset(query_feat)
        sampling_offset = sampling_offset.view(B, Q, self.num_heads * self.num_points * self.depth_num, 2)
        sampling_offset = torch.cat((sampling_offset, torch.zeros_like(sampling_offset[..., 0:1])), dim=-1)
        sampling_points = make_sample_points(query_bbox, sampling_offset, self.pc_range)
        sampling_points = sampling_points.reshape(B, Q, 1, self.num_heads, self.num_points * self.depth_num, 3)
        sampling_points = sampling_points.expand(B, Q, self.num_frames, self.num_heads, self.num_points * self.depth_num, 3)

        time_diff = img_metas[0]['time_diff']
        time_diff = time_diff[:, None, :, None]
        vel = query_ray[..., 8:].detach()
        vel = vel[:, :, None, :]
        dist = vel * time_diff
        dist = dist[:, :, :, None, None, :]
        sampling_points = sampling_points[..., 0:2] - dist

        sampling_points[..., 0:1] = (sampling_points[..., 0:1] - self.pc_range[0]) / (self.pc_range[3] - self.pc_range[0])
        sampling_points[..., 1:2] = (sampling_points[..., 1:2] - self.pc_range[1]) / (self.pc_range[4] - self.pc_range[1])
        sampling_points = xy2theta_d_coods(sampling_points)

        sampling_points = sampling_points.reshape(B, Q, self.num_frames, self.num_heads, self.num_points, self.depth_num, 2)
        sampling_points_d = torch.linspace(-d_region, d_region, self.depth_num).view(1, 1, self.depth_num).repeat(B, Q, 1).to(query_bbox.device)
        sampling_points_d = sampling_points_d + (self.ray_points_offset(query_feat).sigmoid() * 2 - 1) * d_region / self.depth_num / 2
        sampling_points_d = sampling_points_d.view(B, Q, 1, 1, 1, self.depth_num, 1).repeat(1, 1, self.num_frames, self.num_heads, self.num_points, 1, 1)
        sampling_points = torch.cat((sampling_points[..., 0:1], sampling_points[..., 1:2] + sampling_points_d), dim=-1)
        sampling_points = sampling_points.reshape(B, Q, self.num_frames, self.num_heads, self.num_points * self.depth_num, 2)
        sampling_points = theta_d2xy_coods(sampling_points)

        sampling_points = sampling_points.permute(0, 1, 3, 2, 4, 5).contiguous()
        scale_weights = self.scale_weights(query_feat).view(B, Q, self.num_heads, 1, self.num_levels, self.depth_num * self.num_points).contiguous()
        scale_weights = torch.softmax(scale_weights, dim=-1)
        scale_weights = scale_weights.expand(B, Q, self.num_heads, self.num_frames, self.num_levels, self.depth_num * self.num_points).contiguous()

        bev_mask = torch.zeros((B, bev_h, bev_w), device=bev_feats.device).to(bev_feats.dtype)
        bev_pos = self.positional_encoding(bev_mask).to(bev_feats.dtype)
        bev_pos = bev_pos.view(B, 1, self.embed_dims, bev_h, bev_w).repeat(1, self.num_frames, 1, 1, 1)

        sampled_feats = self.attention(query_feat, bev_feats + bev_pos, sampling_points, scale_weights, spatial_shapes=(bev_h, bev_w))
        return sampled_feats

    def forward(self, query_ray, query_feat, bev_feats, img_metas, d_region=0.1):
        if self.training and query_feat.requires_grad:
            return cp(self.inner_forward, query_ray, query_feat, bev_feats, img_metas, d_region=d_region, use_reentrant=False)
        else:
            return self.inner_forward(query_ray, query_feat, bev_feats, img_metas, d_region=d_region)


class AdaptiveMixing(nn.Module):
    """Adaptive channel and point mixing for sampled features."""
    def __init__(self, in_dim, in_points, n_groups=1, query_dim=None, out_dim=None, out_points=None):
        super().__init__()
        out_dim = out_dim if out_dim is not None else in_dim
        out_points = out_points if out_points is not None else in_points
        query_dim = query_dim if query_dim is not None else in_dim

        self.query_dim = query_dim
        self.in_dim = in_dim
        self.in_points = in_points
        self.n_groups = n_groups
        self.out_dim = out_dim
        self.out_points = out_points

        self.eff_in_dim = in_dim // n_groups
        self.eff_out_dim = out_dim // n_groups
        self.m_parameters = self.eff_in_dim * self.eff_out_dim
        self.s_parameters = self.in_points * self.out_points
        self.total_parameters = self.m_parameters + self.s_parameters

        self.parameter_generator = nn.Linear(self.query_dim, self.n_groups * self.total_parameters)
        self.out_proj = nn.Linear(self.eff_out_dim * self.out_points * self.n_groups, self.query_dim)
        self.act = nn.ReLU(inplace=True)

    @torch.no_grad()
    def init_weights(self):
        nn.init.zeros_(self.parameter_generator.weight)

    def inner_forward(self, x, query):
        B, Q, G, P, C = x.shape
        params = self.parameter_generator(query)
        params = params.reshape(B * Q, G, -1)
        out = x.reshape(B * Q, G, P, C)
        M, S = params.split([self.m_parameters, self.s_parameters], 2)
        M = M.reshape(B * Q, G, self.eff_in_dim, self.eff_out_dim)
        S = S.reshape(B * Q, G, self.out_points, self.in_points)
        out = torch.matmul(out, M)
        out = F.layer_norm(out, [out.size(-2), out.size(-1)])
        out = self.act(out)
        out = torch.matmul(S, out)
        out = F.layer_norm(out, [out.size(-2), out.size(-1)])
        out = self.act(out)
        out = out.reshape(B, Q, -1)
        out = self.out_proj(out)
        out = query + out
        return out

    def forward(self, x, query):
        if self.training and x.requires_grad:
            return cp(self.inner_forward, x, query, use_reentrant=False)
        else:
            return self.inner_forward(x, query)
