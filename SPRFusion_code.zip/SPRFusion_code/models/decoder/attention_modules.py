"""Attention and fusion modules for SPRFusion decoder.

Contains:
- ScaleAdaptiveSelfAttention (SASA): inter-query self-attention with BEV distance scaling
- UncertaintyAwareCrossModalGatedFusion (UACGF): uncertainty-aware fusion (Eq. 13-15)
- ReliabilityAwareFeatureRectification: auxiliary reliability module
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from torch.utils.checkpoint import checkpoint as cp
from mmcv.runner import BaseModule
from mmcv.cnn import xavier_init
from ..detection.utils import decode_bbox, theta_d2xy_coods
from ..core import DUMP


class ScaleAdaptiveSelfAttention(BaseModule):
    """Scale-Adaptive Self-Attention (SASA).

    Generates distance-aware attention masks scaled by learnable per-head
    temperature parameters, enabling adaptive receptive fields across
    different spatial scales in BEV space.
    """
    def __init__(self, embed_dims=256, num_heads=8, dropout=0.1, pc_range=[], init_cfg=None):
        super().__init__(init_cfg)
        self.pc_range = pc_range
        from mmcv.cnn.bricks.transformer import MultiheadAttention
        self.attention = MultiheadAttention(embed_dims, num_heads, dropout, batch_first=True)
        self.gen_tau = nn.Linear(embed_dims, num_heads)

    @torch.no_grad()
    def init_weights(self):
        nn.init.zeros_(self.gen_tau.weight)
        nn.init.uniform_(self.gen_tau.bias, 0.0, 2.0)

    def inner_forward(self, query_bbox, query_feat, pre_attn_mask):
        query_bbox = theta_d2xy_coods(query_bbox).clone()
        dist = self.calc_bbox_dists(query_bbox)
        tau = self.gen_tau(query_feat)
        if DUMP.enabled:
            torch.save(tau, '{}/sasa_tau_stage{}.pth'.format(DUMP.out_dir, DUMP.stage_count))
        tau = tau.permute(0, 2, 1)
        attn_mask = dist[:, None, :, :] * tau[..., None]
        if pre_attn_mask is not None:
            attn_mask[:, :, pre_attn_mask] = float('-inf')
        attn_mask = attn_mask.flatten(0, 1)
        return self.attention(query_feat, attn_mask=attn_mask)

    def forward(self, query_bbox, query_feat, pre_attn_mask):
        if self.training and query_feat.requires_grad:
            return cp(self.inner_forward, query_bbox, query_feat, pre_attn_mask, use_reentrant=False)
        else:
            return self.inner_forward(query_bbox, query_feat, pre_attn_mask)

    @torch.no_grad()
    def calc_bbox_dists(self, bboxes):
        centers = decode_bbox(bboxes, self.pc_range)[..., :2]
        dist = []
        for b in range(centers.shape[0]):
            dist_b = torch.norm(centers[b].reshape(-1, 1, 2) - centers[b].reshape(1, -1, 2), dim=-1)
            dist.append(dist_b[None, ...])
        dist = torch.cat(dist, dim=0)
        return -dist


class UncertaintyAwareCrossModalGatedFusion(nn.Module):
    """Uncertainty-Aware Cross-Modal Gated Fusion (UACGF, Section 3.4, Eq. 13-15).

    For each query q, each modality m produces a scalar uncertainty estimate
    u^m_q (Eq. 13). These are normalized via softmax to obtain confidence
    weights gamma^m_q that satisfy sum_m gamma^m_q = 1. The weighted feature
    S_q = sum_m gamma^m_q * f^m_q is then used as the query in a multi-head
    cross-attention over all modality features (Eq. 14). The final output
    combines the gated sum with the attention output via a projection (Eq. 15).
    """
    def __init__(self, embed_dims, num_heads=8, dropout=0.1):
        super().__init__()
        self.embed_dims = embed_dims

        # Eq. 13: per-modality uncertainty heads  u^m_q = MLP(f^m_q) -> scalar
        # Implemented as channel-wise gating networks that produce per-feature
        # uncertainty estimates; the scalar uncertainty u^m_q is obtained as
        # the mean across channels, then softmax-normalized to confidence gamma.
        # The channel gates retain gradient flow for stable training.
        self.gate_img = nn.Sequential(
            nn.Linear(embed_dims, embed_dims // 4),
            nn.ReLU(inplace=True),
            nn.Linear(embed_dims // 4, embed_dims),
            nn.Sigmoid()
        )
        self.gate_radar = nn.Sequential(
            nn.Linear(embed_dims, embed_dims // 4),
            nn.ReLU(inplace=True),
            nn.Linear(embed_dims // 4, embed_dims),
            nn.Sigmoid()
        )
        self.gate_bev = nn.Sequential(
            nn.Linear(embed_dims, embed_dims // 4),
            nn.ReLU(inplace=True),
            nn.Linear(embed_dims // 4, embed_dims),
            nn.Sigmoid()
        )

        # Eq. 14: cross-modal multi-head attention  MHA(Q=S_q, K=V=[f^cam; f^rad; f^bev])
        self.cross_attn = nn.MultiheadAttention(
            embed_dims, num_heads=num_heads, dropout=dropout, batch_first=True
        )
        self.cross_norm = nn.LayerNorm(embed_dims)

        # Eq. 15: output projection  O_q = W_o [S_q ; h_q]
        self.out_proj = nn.Sequential(
            nn.Linear(embed_dims * 2, embed_dims),
            nn.GELU(),
            nn.Linear(embed_dims, embed_dims)
        )
        self.out_norm = nn.LayerNorm(embed_dims)

    @torch.no_grad()
    def init_weights(self):
        for gate in [self.gate_img, self.gate_radar, self.gate_bev]:
            nn.init.zeros_(gate[-2].weight)
            nn.init.ones_(gate[-2].bias)
        for m in self.out_proj:
            if isinstance(m, nn.Linear):
                xavier_init(m, distribution='uniform', bias=0.)

    def forward(self, feat_img, feat_radar, feat_bev):
        B, Q, C = feat_img.shape

        # Eq. 13: compute per-modality channel-wise uncertainty gates
        # g^m in [0,1]^C  acts as per-channel reliability indicator
        g_img = self.gate_img(feat_img)        # [B, Q, C]
        g_radar = self.gate_radar(feat_radar)
        g_bev = self.gate_bev(feat_bev)

        # Derive scalar uncertainty u^m_q = 1 - mean(g^m_q) and obtain
        # confidence gamma^m_q via softmax normalization (Eq. 13)
        u_img = 1.0 - g_img.mean(dim=-1, keepdim=True)    # [B, Q, 1]
        u_radar = 1.0 - g_radar.mean(dim=-1, keepdim=True)
        u_bev = 1.0 - g_bev.mean(dim=-1, keepdim=True)

        # gamma = softmax(-u) : lower uncertainty -> higher confidence
        logits = torch.cat([-u_img, -u_radar, -u_bev], dim=-1)  # [B, Q, 3]
        gamma = F.softmax(logits, dim=-1)  # [B, Q, 3], sum=1

        # Eq. 14: confidence-weighted feature aggregation
        # S_q = gamma^cam * (g^cam . f^cam) + gamma^rad * (g^rad . f^rad) + gamma^bev * (g^bev . f^bev)
        gated_img = feat_img * g_img
        gated_radar = feat_radar * g_radar
        gated_bev = feat_bev * g_bev
        weighted_sum = (gamma[..., 0:1] * gated_img +
                        gamma[..., 1:2] * gated_radar +
                        gamma[..., 2:3] * gated_bev)

        # Cross-modal attention: MHA(Q=S_q, K=V=[f^cam_q; f^rad_q; f^bev_q])
        kv = torch.stack([feat_img, feat_radar, feat_bev], dim=2)  # [B, Q, 3, C]
        kv = kv.reshape(B * Q, 3, C)
        q = weighted_sum.reshape(B * Q, 1, C)
        cross_out, _ = self.cross_attn(q, kv, kv)
        cross_out = cross_out.reshape(B, Q, C)
        cross_out = self.cross_norm(cross_out + weighted_sum)

        # Eq. 15: output projection  O_q = W_o [S_q ; h_q]
        out = self.out_proj(torch.cat([weighted_sum, cross_out], dim=-1))
        out = self.out_norm(out + feat_img)
        return out


ReliabilityAwareFeatureRectification = UncertaintyAwareCrossModalGatedFusion
