"""Semantic Radar-Guided Calibration (SRGC) with Language-Grounded
Semantic Calibration (LGSC) for SPRFusion.

Section 3.4, Eq. 10-12 of the paper.
Implements the Reliability-Guided Sampling Enhancer with 5 parallel
semantic codebooks loaded from external .pt files.
"""
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from ..detection.utils import decode_bbox, theta_d2xy_coods
from ..checkpoint import checkpoint as cp


class SemanticRadarGuidedCalibration(nn.Module):
    """Reliability-Guided Cross-Modal Adaptive Sampling with
    Language-Grounded Semantic Calibration (SRGC).

    Key components:
    1. Cross-modal anchor context extraction from radar BEV
    2. Context-enhanced query via gated fusion
    3. SRGC: 5 parallel semantic codebooks for category-aware calibration
    """
    def __init__(self, embed_dims, num_groups=4, pc_range=[],
                 num_classes=10, lgsc_alpha=0.0, lgsc_prior_dim=64,
                 codebook_path=None):
        super().__init__()
        self.embed_dims = embed_dims
        self.num_groups = num_groups
        self.pc_range = pc_range
        self.num_classes = num_classes
        self.lgsc_prior_dim = lgsc_prior_dim

        # Cross-modal anchor context projection (Eq. 10)
        self.anchor_proj = nn.Sequential(
            nn.Linear(embed_dims, embed_dims),
            nn.LayerNorm(embed_dims),
            nn.ReLU(inplace=True)
        )

        # Context-enhanced query via gated fusion (Eq. 11)
        self.context_gate = nn.Sequential(
            nn.Linear(embed_dims * 2, embed_dims),
            nn.Sigmoid()
        )

        # LGSC branch (Eq. 12)
        self.lgsc_alpha = lgsc_alpha
        if lgsc_alpha > 0:
            self._build_lgsc(embed_dims, num_classes, lgsc_prior_dim, codebook_path)

    def _build_lgsc(self, embed_dims, num_classes, prior_dim, codebook_path):
        """Build the LGSC branch with 5 parallel semantic codebooks."""
        if codebook_path is not None and os.path.exists(codebook_path):
            codebook = torch.load(codebook_path, map_location='cpu')
            if codebook.dim() == 3:
                # [5, K, D] format: 5 parallel codebooks
                self.num_codebooks = codebook.shape[0]
            else:
                # [K, D] format: single codebook
                codebook = codebook.unsqueeze(0)
                self.num_codebooks = 1
        else:
            codebook = self._generate_fallback_codebook(num_classes, prior_dim)
            self.num_codebooks = codebook.shape[0]

        self.register_buffer('semantic_codebook', codebook)

        # Per-codebook projection: W_K and W_V (Eq. 11)
        self.query_to_prior = nn.Linear(embed_dims, prior_dim, bias=False)
        self.codebook_keys = nn.Linear(prior_dim, prior_dim, bias=False)
        self.codebook_values = nn.Linear(prior_dim, prior_dim, bias=False)

        # Aggregation across 5 codebooks -> single calibration signal
        self.prior_to_calib = nn.Sequential(
            nn.Linear(prior_dim, embed_dims),
            nn.LayerNorm(embed_dims),
            nn.Tanh()
        )

        self.lgsc_blend = nn.Parameter(torch.tensor(-5.0))

    @staticmethod
    def _generate_fallback_codebook(num_classes, prior_dim):
        """Generate a fallback codebook when no external file is provided."""
        torch.manual_seed(42)
        codebook = torch.randn(5, num_classes, prior_dim)
        codebook = F.normalize(codebook, dim=-1)
        return codebook

    @torch.no_grad()
    def init_weights(self):
        nn.init.zeros_(self.context_gate[0].weight)
        nn.init.constant_(self.context_gate[0].bias, -2.0)

        if self.lgsc_alpha > 0:
            nn.init.xavier_uniform_(self.query_to_prior.weight, gain=0.01)
            nn.init.xavier_uniform_(self.codebook_keys.weight, gain=0.1)
            nn.init.xavier_uniform_(self.codebook_values.weight, gain=0.1)
            nn.init.zeros_(self.prior_to_calib[0].weight)
            nn.init.zeros_(self.prior_to_calib[0].bias)

    def extract_anchor_context(self, query_bbox, radar_bev_feats):
        """Extract radar BEV features at query anchor positions (Eq. 10)."""
        B, Q, _ = query_bbox.shape
        query_xy = theta_d2xy_coods(query_bbox.clone())
        centers = decode_bbox(query_xy, self.pc_range)[..., :2]

        grid_x = (centers[..., 0:1] - self.pc_range[0]) / (
            self.pc_range[3] - self.pc_range[0]) * 2 - 1
        grid_y = (centers[..., 1:2] - self.pc_range[1]) / (
            self.pc_range[4] - self.pc_range[1]) * 2 - 1
        grid = torch.cat([grid_x, grid_y], dim=-1)
        grid = grid[:, None, :, :]

        bev_current = radar_bev_feats[:, 0]
        context = F.grid_sample(
            bev_current, grid, mode='bilinear',
            padding_mode='zeros', align_corners=False
        )
        context = context.squeeze(2).permute(0, 2, 1)
        return self.anchor_proj(context)

    def semantic_calibration(self, query_feat, anchor_context):
        """LGSC: 5 parallel codebook attention and averaging (Eq. 12)."""
        q_prior = self.query_to_prior(query_feat)  # [B, Q, D]

        # Process each codebook and average
        calib_sum = 0
        for i in range(self.num_codebooks):
            cb = self.semantic_codebook[i]  # [K, D]
            keys = self.codebook_keys(cb)   # [K, D]
            values = self.codebook_values(cb)  # [K, D]

            attn_logits = torch.matmul(q_prior, keys.t()) / (self.lgsc_prior_dim ** 0.5)
            attn_weights = F.softmax(attn_logits, dim=-1)
            semantic_prior = torch.matmul(attn_weights, values)
            calib_sum = calib_sum + semantic_prior

        calib_avg = calib_sum / self.num_codebooks  # [B, Q, D]
        calib = self.prior_to_calib(calib_avg)

        blend = torch.sigmoid(self.lgsc_blend) * self.lgsc_alpha
        return anchor_context + blend * calib

    def enhance_query(self, query_feat, anchor_context):
        """Gated fusion of radar anchor context into query (Eq. 11)."""
        gate = self.context_gate(
            torch.cat([query_feat, anchor_context], dim=-1))
        return query_feat + gate * anchor_context

    def inner_forward(self, query_bbox, query_feat, radar_bev_feats):
        anchor_context = self.extract_anchor_context(query_bbox, radar_bev_feats)
        if self.lgsc_alpha > 0:
            anchor_context = self.semantic_calibration(query_feat, anchor_context)
        enhanced_query = self.enhance_query(query_feat, anchor_context)
        return enhanced_query

    def forward(self, query_bbox, query_feat, radar_bev_feats):
        if self.training and query_feat.requires_grad:
            return cp(self.inner_forward, query_bbox, query_feat,
                      radar_bev_feats, use_reentrant=False)
        else:
            return self.inner_forward(query_bbox, query_feat, radar_bev_feats)


    def _load_from_state_dict(self, state_dict, prefix, local_metadata,
                             strict, missing_keys, unexpected_keys, error_msgs):
        """Handle backward compatibility for old checkpoints.

        Old checkpoints have semantic_codebook with shape [K, D] (single codebook).
        New code expects [5, K, D] (5 parallel codebooks).
        Also handles missing codebook_keys/codebook_values parameters.
        """
        cb_key = prefix + 'semantic_codebook'
        if cb_key in state_dict:
            old_cb = state_dict[cb_key]
            if old_cb.dim() == 2:
                # Expand single codebook to 5 parallel codebooks
                state_dict[cb_key] = old_cb.unsqueeze(0).expand(5, -1, -1).clone()

        super()._load_from_state_dict(
            state_dict, prefix, local_metadata,
            strict, missing_keys, unexpected_keys, error_msgs)

# Backward-compatible alias
ReliabilityGuidedSamplingEnhancer = SemanticRadarGuidedCalibration
