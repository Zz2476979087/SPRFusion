"""SPRFusion Transformer Decoder: orchestrates the full decoding pipeline.

Contains:
- SPRFusionTransformer: top-level transformer with CMTA + decoder
- SPRFusionDecoder: iterative decoder running all layers
- SPRFusionDecoderLayer: single decoder layer with sampling, fusion, detection heads
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from mmcv.runner import BaseModule
from mmcv.cnn import bias_init_with_prob
from mmcv.cnn.bricks.transformer import FFN
from mmdet.models.utils.builder import TRANSFORMER

from ..detection.utils import decode_bbox, theta_d2xy_coods, xy2theta_d_coods
from ..core import inverse_sigmoid, DUMP
from ..ops.wrapper import MSMV_CUDA
from ..sampling.sparse_sampling import sampling_4d, make_sample_points

from .attention_modules import ScaleAdaptiveSelfAttention
from .adaptive_sampling import SPRFusionSampling, BEVSampling, AdaptiveMixing
from .temporal_alignment import CrossModalTemporalBEVEncoder
from .attention_modules import UncertaintyAwareCrossModalGatedFusion
from .semantic_calibration import SemanticRadarGuidedCalibration


@TRANSFORMER.register_module(name='SPRFusionTransformer')
class SPRFusionTransformer(BaseModule):
    """Top-level transformer: CMTA temporal encoding + iterative decoder."""
    def __init__(self, embed_dims, num_frames=8, num_points=4,
                 num_points_bev=4, num_layers=6, num_levels=4,
                 num_classes=10, code_size=10, img_depth_num=3,
                 bev_depth_num=5, pc_range=[], num_ray=150,
                 d_region_list=[0.15, 0.1, 0.1, 0.08, 0.08, 0.05],
                 spatial_shapes=(128, 128),
                 lgsc_alpha=0.0, lgsc_prior_dim=64,
                 codebook_path=None, init_cfg=None):
        assert init_cfg is None
        super().__init__(init_cfg=init_cfg)
        self.embed_dims = embed_dims
        self.pc_range = pc_range

        self.decoder = SPRFusionDecoder(
            embed_dims, num_frames, num_points, num_points_bev,
            num_layers, num_levels, num_classes, code_size,
            img_depth_num=img_depth_num, bev_depth_num=bev_depth_num,
            pc_range=pc_range, num_ray=num_ray,
            d_region_list=d_region_list, spatial_shapes=spatial_shapes,
            lgsc_alpha=lgsc_alpha, lgsc_prior_dim=lgsc_prior_dim,
            codebook_path=codebook_path)

        # CMTA: Cross-Modal Temporal BEV Alignment (Section 3.1)
        self.cam_temporal_encoder = CrossModalTemporalBEVEncoder(
            embed_dims=embed_dims, hidden_dims=64, num_frames=num_frames)

    @torch.no_grad()
    def init_weights(self):
        self.decoder.init_weights()
        self.cam_temporal_encoder.init_weights()

    def forward(self, query_bbox, query_feat, mlvl_feats, lss_bev_feats,
                radar_bev_feats, attn_mask, img_metas):
        # CMTA: enhance camera BEV with radar-guided temporal alignment
        lss_bev_feats = self.cam_temporal_encoder(lss_bev_feats, radar_bev_feats)

        cls_scores, bbox_preds = self.decoder(
            query_bbox, query_feat, mlvl_feats, lss_bev_feats,
            radar_bev_feats, attn_mask, img_metas)

        cls_scores = torch.nan_to_num(cls_scores)
        bbox_preds = torch.nan_to_num(bbox_preds)
        return cls_scores, bbox_preds

# Backward-compatible alias


class SPRFusionDecoder(BaseModule):
    """Iterative decoder: runs shared decoder layer num_layers times."""
    def __init__(self, embed_dims, num_frames=8, num_points=4,
                 num_points_bev=4, num_layers=6, num_levels=4,
                 num_classes=10, code_size=10, img_depth_num=3,
                 bev_depth_num=5, pc_range=[], num_ray=150,
                 d_region_list=[0.15, 0.1, 0.1, 0.08, 0.08, 0.05],
                 spatial_shapes=(128, 128),
                 lgsc_alpha=0.0, lgsc_prior_dim=64,
                 codebook_path=None, init_cfg=None):
        super().__init__(init_cfg)
        self.num_layers = num_layers
        self.pc_range = pc_range

        self.decoder_layer = SPRFusionDecoderLayer(
            embed_dims, num_frames, num_points, num_points_bev,
            num_levels, num_classes, code_size,
            img_depth_num=img_depth_num, bev_depth_num=bev_depth_num,
            num_ray=num_ray, pc_range=pc_range,
            d_region_list=d_region_list, spatial_shapes=spatial_shapes,
            lgsc_alpha=lgsc_alpha, lgsc_prior_dim=lgsc_prior_dim,
            codebook_path=codebook_path)

    @torch.no_grad()
    def init_weights(self):
        self.decoder_layer.init_weights()

    def forward(self, query_bbox, query_feat, mlvl_feats, lss_bev_feats,
                radar_bev_feats, attn_mask, img_metas):
        cls_scores, bbox_preds = [], []

        # Compute time differences from timestamps
        timestamps = np.array([m['img_timestamp'] for m in img_metas], dtype=np.float64)
        timestamps = np.reshape(timestamps, [query_bbox.shape[0], -1, 6])
        time_diff = timestamps[:, :1, :] - timestamps
        time_diff = np.mean(time_diff, axis=-1).astype(np.float32)
        time_diff = torch.from_numpy(time_diff).to(query_bbox.device)
        img_metas[0]['time_diff'] = time_diff

        # Organize projection matrices
        lidar2img = np.asarray([m['lidar2img'] for m in img_metas]).astype(np.float32)
        lidar2img = torch.from_numpy(lidar2img).to(query_bbox.device)
        img_metas[0]['lidar2img'] = lidar2img

        # Pre-process multi-level image features for sampling
        for lvl, feat in enumerate(mlvl_feats):
            B, TN, GC, H, W = feat.shape
            N, T, G, C = 6, TN // 6, 4, GC // 4
            feat = feat.reshape(B, T, N, G, C, H, W)
            if MSMV_CUDA:
                feat = feat.permute(0, 1, 3, 2, 5, 6, 4)
                feat = feat.reshape(B * T * G, N, H, W, C)
            else:
                feat = feat.permute(0, 1, 3, 4, 2, 5, 6)
                feat = feat.reshape(B * T * G, C, N, H, W)
            mlvl_feats[lvl] = feat.contiguous()

        for i in range(self.num_layers):
            DUMP.stage_count = i
            query_feat, cls_score, bbox_pred = self.decoder_layer(
                query_bbox, query_feat, mlvl_feats, lss_bev_feats,
                radar_bev_feats, attn_mask, img_metas, layer=i)
            query_bbox = bbox_pred.clone().detach()
            bbox_pred = theta_d2xy_coods(bbox_pred)
            cls_scores.append(cls_score)
            bbox_preds.append(bbox_pred)

        cls_scores = torch.stack(cls_scores)
        bbox_preds = torch.stack(bbox_preds)
        return cls_scores, bbox_preds

# Backward-compatible alias


class SPRFusionDecoderLayer(BaseModule):
    """Single decoder layer: self-attn -> SRGC -> sampling -> mixing -> UACGF -> FFN."""
    def __init__(self, embed_dims, num_frames=8, num_points=4,
                 num_points_bev=4, num_levels=4, num_classes=10,
                 code_size=10, num_cls_fcs=2, num_reg_fcs=2,
                 img_depth_num=3, bev_depth_num=5, num_ray=150,
                 pc_range=[], d_region_list=[0.15, 0.1, 0.1, 0.08, 0.08, 0.05],
                 spatial_shapes=(128, 128),
                 lgsc_alpha=0.0, lgsc_prior_dim=64,
                 codebook_path=None, init_cfg=None):
        super().__init__(init_cfg)
        self.embed_dims = embed_dims
        self.num_classes = num_classes
        self.code_size = code_size
        self.pc_range = pc_range

        self.position_encoder = nn.Sequential(
            nn.Linear(3, self.embed_dims),
            nn.LayerNorm(self.embed_dims),
            nn.ReLU(inplace=True),
            nn.Linear(self.embed_dims, self.embed_dims),
            nn.LayerNorm(self.embed_dims),
            nn.ReLU(inplace=True),
        )

        self.self_attn = ScaleAdaptiveSelfAttention(
            embed_dims, num_heads=8, dropout=0.1, pc_range=pc_range)
        self.sampling = SPRFusionSampling(
            embed_dims, num_frames=num_frames, num_groups=4,
            num_points=num_points, num_levels=num_levels,
            depth_num=img_depth_num, pc_range=pc_range)
        self.sampling_radar_bev = BEVSampling(
            embed_dims, num_frames=num_frames, num_heads=4,
            num_points=num_points_bev, num_levels=1, pc_range=pc_range,
            depth_num=bev_depth_num, spatial_shapes=spatial_shapes,
            temp_radar=True)
        self.sampling_lss_bev = BEVSampling(
            embed_dims, num_frames=num_frames, num_heads=4,
            num_points=num_points_bev, num_levels=1, pc_range=pc_range,
            depth_num=bev_depth_num, spatial_shapes=spatial_shapes)

        self.mixing = AdaptiveMixing(
            in_dim=embed_dims,
            in_points=num_points * num_frames * img_depth_num,
            n_groups=4, out_points=128)
        self.ffn = FFN(embed_dims, feedforward_channels=512, ffn_drop=0.1)

        self.norm1 = nn.LayerNorm(embed_dims)
        self.norm2 = nn.LayerNorm(embed_dims)
        self.norm3 = nn.LayerNorm(embed_dims)

        # UACGF: Uncertainty-Aware Cross-Modal Gated Fusion (Section 3.4)
        self.fusion = UncertaintyAwareCrossModalGatedFusion(embed_dims)

        # SRGC: Semantic Radar-Guided Calibration (Section 3.4)
        self.rgas = SemanticRadarGuidedCalibration(
            embed_dims, num_groups=4, pc_range=pc_range,
            num_classes=num_classes, lgsc_alpha=lgsc_alpha,
            lgsc_prior_dim=lgsc_prior_dim,
            codebook_path=codebook_path)

        self.norm_radar_bev = nn.LayerNorm(embed_dims)
        self.norm_lss_bev = nn.LayerNorm(embed_dims)

        cls_branch = []
        for _ in range(num_cls_fcs):
            cls_branch.append(nn.Linear(self.embed_dims, self.embed_dims))
            cls_branch.append(nn.LayerNorm(self.embed_dims))
            cls_branch.append(nn.ReLU(inplace=True))
        cls_branch.append(nn.Linear(self.embed_dims, self.num_classes))
        self.cls_branch = nn.Sequential(*cls_branch)

        reg_branch = []
        for _ in range(num_reg_fcs):
            reg_branch.append(nn.Linear(self.embed_dims, self.embed_dims))
            reg_branch.append(nn.ReLU(inplace=True))
        reg_branch.append(nn.Linear(self.embed_dims, self.code_size))
        self.reg_branch = nn.Sequential(*reg_branch)

        self.d_region_list = d_region_list
        self.num_ray = num_ray

    @torch.no_grad()
    def init_weights(self):
        self.self_attn.init_weights()
        self.sampling.init_weights()
        self.mixing.init_weights()
        self.sampling_radar_bev.init_weights()
        self.sampling_lss_bev.init_weights()
        bias_init = bias_init_with_prob(0.01)
        nn.init.constant_(self.cls_branch[-1].bias, bias_init)
        self.fusion.init_weights()
        self.rgas.init_weights()

    def refine_bbox(self, bbox_proposal, bbox_delta):
        dz = inverse_sigmoid(bbox_proposal[..., 1:3])
        dz_delta = bbox_delta[..., 1:3]
        dz_new = torch.sigmoid(dz_delta + dz)
        theta = bbox_proposal[..., 0:1] + (torch.sigmoid(bbox_delta[..., 0:1]) * 2 - 1) / self.num_ray
        return torch.cat([theta, dz_new, bbox_delta[..., 3:]], dim=-1)

    def forward(self, query_bbox, query_feat, mlvl_feats, lss_bev_feats,
                radar_bev_feats, attn_mask, img_metas, layer=0):
        query_pos = self.position_encoder(query_bbox[..., :3])
        query_feat = query_feat + query_pos

        query_feat = self.norm1(self.self_attn(query_bbox, query_feat, attn_mask))

        # SRGC: cross-modal anchor context for sampling guidance
        enhanced_query = self.rgas(query_bbox, query_feat, radar_bev_feats)

        query_radar_feat = self.sampling_radar_bev(
            query_bbox, query_feat, radar_bev_feats, img_metas,
            d_region=self.d_region_list[layer])
        query_radar_feat = self.norm_radar_bev(query_radar_feat)

        query_lss_feat = self.sampling_lss_bev(
            query_bbox, query_feat, lss_bev_feats, img_metas,
            d_region=self.d_region_list[layer])
        query_lss_feat = self.norm_lss_bev(query_lss_feat)

        # Image-view sampling with radar-guided enhanced query
        sampled_feat = self.sampling(
            query_bbox, enhanced_query, mlvl_feats, img_metas,
            d_region=self.d_region_list[layer])

        query_feat = self.norm2(self.mixing(sampled_feat, query_feat))
        query_feat = self.fusion(query_feat, query_radar_feat, query_lss_feat)
        query_feat = self.norm3(self.ffn(query_feat))

        cls_score = self.cls_branch(query_feat)
        bbox_pred = self.reg_branch(query_feat)
        bbox_pred = self.refine_bbox(query_bbox, bbox_pred)

        time_diff = img_metas[0]['time_diff']
        if time_diff.shape[1] > 1:
            time_diff = time_diff.clone()
            time_diff[time_diff < 1e-5] = 1.0
            bbox_pred[..., 8:] = bbox_pred[..., 8:] / time_diff[:, 1:2, None]

        if DUMP.enabled:
            query_bbox_dec = decode_bbox(query_bbox, self.pc_range)
            bbox_pred_dec = decode_bbox(bbox_pred, self.pc_range)
            cls_score_sig = torch.sigmoid(cls_score)
            torch.save(query_bbox_dec, '{}/query_bbox_stage{}.pth'.format(DUMP.out_dir, DUMP.stage_count))
            torch.save(bbox_pred_dec, '{}/bbox_pred_stage{}.pth'.format(DUMP.out_dir, DUMP.stage_count))
            torch.save(cls_score_sig, '{}/cls_score_stage{}.pth'.format(DUMP.out_dir, DUMP.stage_count))

        return query_feat, cls_score, bbox_pred

# Backward-compatible aliases
