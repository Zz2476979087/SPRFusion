"""Cross-Modal Temporal BEV Alignment (CMTA) and radar temporal encoding."""
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.runner import BaseModule
from ..checkpoint import checkpoint as cp


class CrossModalTemporalBEVEncoder(BaseModule):
    """Cross-Modal Temporal BEV Alignment (CMTA, Section 3.1, Eq. 1-3).

    Enhances camera BEV features with temporal modeling guided by radar BEV.
    1. Radar-guided deformable alignment of camera BEV across frames.
    2. ConvGRU temporal fusion on aligned features.
    3. Cross-modal spatial gating for selective enhancement.
    """
    def __init__(self, embed_dims=256, hidden_dims=64, num_frames=8,
                 kernel_size=3, downsample_ratio=2):
        super().__init__()
        self.embed_dims = embed_dims
        self.hidden_dims = hidden_dims
        self.downsample_ratio = downsample_ratio

        self.cam_down = nn.Conv2d(embed_dims, hidden_dims, 3,
                                  stride=downsample_ratio, padding=1)
        self.radar_down = nn.Conv2d(embed_dims, hidden_dims, 3,
                                    stride=downsample_ratio, padding=1)

        # Radar-guided deformable offset for camera BEV alignment (Eq. 1)
        self.offset_net = nn.Sequential(
            nn.Conv2d(hidden_dims * 2, hidden_dims, 3, padding=1, bias=False),
            nn.BatchNorm2d(hidden_dims),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_dims, 2, 3, padding=1)
        )

        # Temporal ConvGRU (Eq. 2)
        self.convGRU = ConvGRU(hidden_dims, hidden_dims, kernel_size)

        # Cross-modal spatial gating (Eq. 3)
        self.cross_gate = nn.Sequential(
            nn.Conv2d(hidden_dims * 2, hidden_dims, 3, padding=1, bias=False),
            nn.BatchNorm2d(hidden_dims),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden_dims, hidden_dims, 1),
            nn.Sigmoid()
        )

        self.upsample = nn.Sequential(
            nn.Upsample(scale_factor=downsample_ratio, mode='bilinear', align_corners=True),
            nn.Conv2d(hidden_dims, hidden_dims, 3, padding=1))
        self.temporal_fusion = nn.Conv2d(embed_dims + hidden_dims, embed_dims,
                                         kernel_size, padding=kernel_size // 2)

        # Identity-start residual for stable training
        self.residual_scale = nn.Parameter(torch.tensor(-5.0))

    def init_weights(self):
        nn.init.zeros_(self.offset_net[-1].weight)
        nn.init.zeros_(self.offset_net[-1].bias)

    def _warp(self, feat, offset):
        B, C, H, W = feat.shape
        grid_y, grid_x = torch.meshgrid(
            torch.linspace(-1, 1, H, device=feat.device, dtype=feat.dtype),
            torch.linspace(-1, 1, W, device=feat.device, dtype=feat.dtype),
            indexing='ij')
        grid = torch.stack([grid_x, grid_y], dim=-1).unsqueeze(0).expand(B, -1, -1, -1)
        grid = grid + offset.permute(0, 2, 3, 1)
        return F.grid_sample(feat, grid, mode='bilinear', padding_mode='zeros', align_corners=True)

    def inner_forward(self, cam_bev, radar_bev):
        B, T, C, H, W = cam_bev.shape
        cam_d = self.cam_down(cam_bev.flatten(0, 1))
        radar_d = self.radar_down(radar_bev.flatten(0, 1))

        offset = self.offset_net(torch.cat([cam_d, radar_d], dim=1))
        offset = torch.tanh(offset) * 0.1
        cam_aligned = self._warp(cam_d, offset)

        _, hd, h, w = cam_aligned.shape
        cam_aligned = cam_aligned.reshape(B, T, hd, h, w)
        radar_d = radar_d.reshape(B, T, hd, h, w)

        cam_temporal = self.convGRU(cam_aligned)
        gate = self.cross_gate(
            torch.cat([cam_temporal.flatten(0, 1), radar_d.flatten(0, 1)], dim=1)
        ).reshape(B, T, hd, h, w)
        cam_temporal = cam_temporal * gate

        cam_up = self.upsample(cam_temporal.flatten(0, 1)).reshape(B, T, hd, H, W)
        out = self.temporal_fusion(
            torch.cat([cam_bev.flatten(0, 1), cam_up.flatten(0, 1)], dim=1)
        ).reshape(B, T, C, H, W)

        scale = torch.sigmoid(self.residual_scale)
        out = cam_bev + scale * (out - cam_bev)
        return out

    def forward(self, cam_bev, radar_bev):
        if self.training and cam_bev.requires_grad:
            return cp(self.inner_forward, cam_bev, radar_bev, use_reentrant=False)
        else:
            return self.inner_forward(cam_bev, radar_bev)


class RadarBEVTemporalEncoder(BaseModule):
    """Temporal encoding for radar BEV features using ConvGRU."""
    def __init__(self, embed_dims=256, hidden_dims=64, num_frames=8,
                 kernel_size=3, downsample_ratio=2, init_cfg=None):
        super().__init__(init_cfg)
        self.num_frames = num_frames
        self.embed_dims = embed_dims
        self.hidden_dims = hidden_dims
        self.convGRU = ConvGRU(input_channels=hidden_dims, hidden_channels=hidden_dims, kernel_size=kernel_size)
        self.temporal_fusion = nn.Conv2d(embed_dims + hidden_dims, embed_dims, kernel_size, padding=kernel_size // 2)
        self.downsample_ratio = downsample_ratio
        self.downsample = nn.Conv2d(embed_dims, hidden_dims, kernel_size=3, stride=downsample_ratio, padding=1)
        self.upsample = nn.Sequential(
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
            nn.Conv2d(hidden_dims, hidden_dims, kernel_size=3, padding=1))

    def init_weights(self):
        self.convGRU.init_weights()

    def inner_forward(self, bev_feats):
        B, T, C, H, W = bev_feats.shape
        bev_feats_down = self.downsample(bev_feats.flatten(0, 1)).reshape(
            B, T, self.hidden_dims, H // self.downsample_ratio, W // self.downsample_ratio)
        bev_h_feats = self.convGRU(bev_feats_down)
        bev_h_feats = self.upsample(bev_h_feats.flatten(0, 1)).reshape(B, T, self.hidden_dims, H, W)
        bev_feats = torch.cat((bev_feats, bev_h_feats), dim=2)
        bev_feats = bev_feats.flatten(0, 1)
        bev_feats = self.temporal_fusion(bev_feats).reshape(B, T, C, H, W)
        return bev_feats

    def forward(self, bev_feats):
        if self.training and bev_feats.requires_grad:
            return cp(self.inner_forward, bev_feats, use_reentrant=False)
        else:
            return self.inner_forward(bev_feats)


class ConvGRU(BaseModule):
    """Convolutional GRU for temporal feature aggregation."""
    def __init__(self, input_channels, hidden_channels, kernel_size):
        super().__init__()
        self.convGRUCell = ConvGRUCell(input_channels, hidden_channels, kernel_size)
        self.hidden_channels = hidden_channels

    def forward(self, x):
        B, T, C, H, W = x.shape
        h = torch.zeros(B, self.hidden_channels, H, W, device=x.device)
        h0 = h.clone().detach()
        out = []
        x_unfold = x.permute(1, 0, 2, 3, 4)
        num_t = 4 if T > 4 else T
        for t in range(T):
            if t >= num_t:
                out.append(h0)
                continue
            x_t = x_unfold[t]
            if t > 1:
                with torch.no_grad():
                    h = self.convGRUCell(x_t, h)
            else:
                h = self.convGRUCell(x_t, h)
            out.append(h)
        return torch.stack(out, dim=1)


class ConvGRUCell(BaseModule):
    """Single ConvGRU cell with fused gate computation."""
    def __init__(self, input_channels, hidden_channels, kernel_size):
        super().__init__()
        padding = kernel_size // 2
        self.hidden_channels = hidden_channels
        self.gates_conv = nn.Conv2d(
            input_channels + hidden_channels,
            3 * hidden_channels,
            kernel_size=kernel_size,
            padding=padding
        )
        self.matching_layer = nn.Conv2d(hidden_channels, input_channels, 1)

    def forward(self, x, h_prev):
        h_matched = self.matching_layer(h_prev)
        combined = torch.cat([x, h_matched], dim=1)
        gates = self.gates_conv(combined)
        z_gate, r_gate, h_candidate = torch.split(gates, self.hidden_channels, dim=1)
        z = torch.sigmoid(z_gate)
        r = torch.sigmoid(r_gate)
        h_candidate = torch.tanh(h_candidate + r * h_prev)
        h_next = (1 - z) * h_prev + z * h_candidate
        return h_next
