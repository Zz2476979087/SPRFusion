# Copyright (c) OpenMMLab. All rights reserved.
# modified from megvii-bevdepth.
import math
import os

import torch
from mmcv.runner.dist_utils import master_only
from mmcv.runner.hooks import HOOKS, Hook

from .utils import is_parallel

__all__ = ['ModelEMA', 'EMAEvalHook', 'EMADistEvalHook']


class ModelEMA:
    """Full-state_dict Exponential Moving Average.

    This version keeps an EMA of the whole model state_dict, including:
    - floating-point parameters
    - floating-point buffers (e.g. BatchNorm running_mean/running_var)

    Non-floating tensors (e.g. num_batches_tracked) are copied directly
    from the current model state when updating / saving / swapping.
    """

    def __init__(self, model, decay=0.9999, updates=0):
        """
        Args:
            model (nn.Module): model to apply EMA. Can be DP/DDP wrapped.
            decay (float): ema decay rate.
            updates (int): counter of EMA updates.
        """
        base_model = model.module if is_parallel(model) else model

        # Keep EMA shadow for the full state_dict
        self.shadow = {}
        model_sd = base_model.state_dict()
        for name, tensor in model_sd.items():
            if tensor.is_floating_point():
                self.shadow[name] = tensor.detach().cpu().float().clone()
            else:
                # keep non-floating buffers too, for completeness
                self.shadow[name] = tensor.detach().cpu().clone()

        self.updates = updates
        self.decay = lambda x: decay * (1 - math.exp(-x / 2000))

    def update(self, trainer, model):
        """Update EMA from current model state_dict."""
        with torch.no_grad():
            self.updates += 1
            d = self.decay(self.updates)

            base_model = model.module if is_parallel(model) else model
            model_sd = base_model.state_dict()

            for name, tensor in model_sd.items():
                model_v = tensor.detach().cpu()

                if name not in self.shadow:
                    # In case new state appears unexpectedly
                    self.shadow[name] = (
                        model_v.float().clone()
                        if model_v.is_floating_point()
                        else model_v.clone()
                    )
                    continue

                if model_v.is_floating_point():
                    ema_v = self.shadow[name]
                    if not ema_v.is_floating_point():
                        ema_v = ema_v.float()
                    self.shadow[name] = ema_v.mul(d).add((1.0 - d) * model_v.float())
                else:
                    # For int / bool buffers like num_batches_tracked, keep latest value
                    self.shadow[name] = model_v.clone()


@HOOKS.register_module()
class MEGVIIEMAHook(Hook):
    """EMAHook used in BEVDepth, modified to keep full-state_dict EMA."""

    def __init__(self, init_updates=0, decay=0.9990, resume=None, interval=1):
        super().__init__()
        self.init_updates = init_updates
        self.resume = resume
        self.decay = decay
        self.interval = interval

    def before_run(self, runner):
        from torch.nn.modules.batchnorm import SyncBatchNorm

        bn_model_list = []
        bn_model_dist_group_list = []
        for model_ref in runner.model.modules():
            if isinstance(model_ref, SyncBatchNorm):
                bn_model_list.append(model_ref)
                bn_model_dist_group_list.append(model_ref.process_group)
                model_ref.process_group = None

        runner.ema_model = ModelEMA(runner.model, self.decay)

        for bn_model, dist_group in zip(bn_model_list, bn_model_dist_group_list):
            bn_model.process_group = dist_group

        runner.ema_model.updates = self.init_updates

        if self.resume is not None:
            runner.logger.info(f'resume ema checkpoint from {self.resume}')
            cpt = torch.load(self.resume, map_location='cpu')
            runner.ema_model.shadow = {
                k: (
                    v.detach().cpu().float().clone()
                    if v.is_floating_point()
                    else v.detach().cpu().clone()
                )
                for k, v in cpt['state_dict'].items()
            }
            runner.ema_model.updates = cpt.get('updates', self.init_updates)

    def after_train_iter(self, runner):
        # runner.model is DP/DDP wrapper; ModelEMA handles unwrap itself
        runner.ema_model.update(runner, runner.model)

    def after_train_epoch(self, runner):
        self.save_checkpoint(runner)

    @master_only
    def save_checkpoint(self, runner):
        # Save a full model-like state_dict so that it can be loaded
        # by mmcv.load_checkpoint(strict=True) in val.py.
        shadow = runner.ema_model.shadow
        model = runner.model.module if is_parallel(runner.model) else runner.model

        model_sd = model.state_dict()
        ema_state = {}

        for name, tensor in model_sd.items():
            if name in shadow:
                shadow_v = shadow[name]
                ema_state[name] = shadow_v.to(tensor.device, dtype=tensor.dtype)
            else:
                ema_state[name] = tensor.detach().clone()

        ema_checkpoint = {
            'epoch': runner.epoch,
            'state_dict': ema_state,
            'updates': runner.ema_model.updates
        }

        save_path = f'epoch_{runner.epoch + 1}_ema.pth'
        save_path = os.path.join(runner.work_dir, save_path)

        if (runner.epoch + 1) % self.interval == 0:
            torch.save(ema_checkpoint, save_path)

        runner.logger.info(f'Saving ema checkpoint at {save_path}')


def _swap_ema_weights(runner):
    """Swap model weights/buffers with EMA weights in-place. Call again to swap back."""
    if not hasattr(runner, 'ema_model'):
        return False

    shadow = runner.ema_model.shadow
    model = runner.model.module if is_parallel(runner.model) else runner.model

    model_sd = model.state_dict()
    new_state = {}

    for name, tensor in model_sd.items():
        if name in shadow:
            shadow_v = shadow[name]
            # save current model tensor into shadow for swap-back
            if tensor.is_floating_point():
                shadow[name] = tensor.detach().cpu().float().clone()
            else:
                shadow[name] = tensor.detach().cpu().clone()

            new_state[name] = shadow_v.to(tensor.device, dtype=tensor.dtype)
        else:
            new_state[name] = tensor

    model.load_state_dict(new_state, strict=True)
    return True


class EMAEvalHook:
    """Inherits mmdet EvalHook, swaps in EMA weights for validation."""

    _base_cls = None

    def __new__(cls, *args, **kwargs):
        from mmdet.core import EvalHook as _BaseEvalHook
        if cls._base_cls is None:
            cls._base_cls = type(
                'EMAEvalHook',
                (_BaseEvalHook,),
                {'_do_evaluate': cls._ema_do_evaluate},
            )
        return cls._base_cls(*args, **kwargs)

    @staticmethod
    def _ema_do_evaluate(self, runner):
        from mmdet.core import EvalHook as _BaseEvalHook
        swapped = _swap_ema_weights(runner)
        try:
            _BaseEvalHook._do_evaluate(self, runner)
        finally:
            if swapped:
                _swap_ema_weights(runner)


class EMADistEvalHook:
    """Inherits mmdet DistEvalHook, swaps in EMA weights for validation."""

    _base_cls = None

    def __new__(cls, *args, **kwargs):
        from mmdet.core import DistEvalHook as _BaseDistEvalHook
        if cls._base_cls is None:
            cls._base_cls = type(
                'EMADistEvalHook',
                (_BaseDistEvalHook,),
                {'_do_evaluate': cls._ema_do_evaluate},
            )
        return cls._base_cls(*args, **kwargs)

    @staticmethod
    def _ema_do_evaluate(self, runner):
        from mmdet.core import DistEvalHook as _BaseDistEvalHook
        swapped = _swap_ema_weights(runner)
        try:
            _BaseDistEvalHook._do_evaluate(self, runner)
        finally:
            if swapped:
                _swap_ema_weights(runner)