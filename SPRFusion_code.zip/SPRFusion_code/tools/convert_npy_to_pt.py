"""Convert .npy codebook files to .pt format."""
import torch
import torch.nn.functional as F
import numpy as np
import os

assets = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'assets')

for name in ['nuscenes', 'vod']:
    npy_path = os.path.join(assets, f'semantic_codebook_{name}.npy')
    pt_path = os.path.join(assets, f'semantic_codebook_{name}.pt')
    if os.path.exists(npy_path):
        arr = np.load(npy_path)
        tensor = torch.from_numpy(arr).float()
        tensor = F.normalize(tensor, dim=-1)
        torch.save(tensor, pt_path)
        print(f'Converted {npy_path} -> {pt_path}: shape={tensor.shape}')
    else:
        print(f'Skipping {name}: {npy_path} not found')

print('Done!')
