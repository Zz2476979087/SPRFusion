
#!/usr/bin/env python3
"""
ego_vs_aligned_viz.py  --  Figure 3(a)
Ego-motion compensation ghosting vs SPRFusion temporal alignment.

Generates a single 1x2 BEV figure:
  Left :  ego-comp ghost boxes (t-2, t-1) + GT(t)  -> Spatiotemporal Ghosting
  Right:  SPRFusion prediction at frame t vs GT(t)  -> aligned, ghost-free

Map raster matches visual/plot_bev_comparison_grid.py (NuScenesMap.get_map_mask).

Usage:
    python tools/ego_vs_aligned_viz.py \
        --dataroot  data/nuscenes \
        --results_json submission/pts_bbox/results_nusc.json \
        --save_dir  visual
"""

import os, sys, json, copy, math, argparse, warnings

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

warnings.filterwarnings("ignore")

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

import torch
torch.set_grad_enabled(False)

from nuscenes.nuscenes import NuScenes
from nuscenes.utils.data_classes import Box
from nuscenes.eval.detection.utils import category_to_detection_name
from pyquaternion import Quaternion

# Optional: nuScenes map-expansion (get_map_mask)
try:
    from nuscenes.map_expansion.map_api import NuScenesMap
    HAS_MAP = True
except ImportError:
    HAS_MAP = False

# ───────────────────── constants ─────────────────────
BEV_RANGE = 51.2
VEHICLE_CLASSES = frozenset({"car", "truck", "bus", "trailer", "construction_vehicle"})
MIN_DISPLACEMENT = 5.0  # metres – skip nearly-static vehicles

MAP_CANVAS_PX = 800
BG_ROAD_MAP = np.array([0.55, 0.55, 0.55], dtype=np.float32)
BG_NON_ROAD_MAP = np.array([0.85, 0.85, 0.85], dtype=np.float32)

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans", "Arial", "Helvetica"],
    "font.size": 10,
    "axes.labelsize": 12,
    "axes.titlesize": 14,
    "mathtext.default": "regular",
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.08,
})

# ───────────────────── geometry helpers ─────────────────────

def _lidar_meta(nusc, sample_token):
    """Return calibrated_sensor & ego_pose dicts for LIDAR_TOP."""
    s = nusc.get("sample", sample_token)
    sd = nusc.get("sample_data", s["data"]["LIDAR_TOP"])
    cs = nusc.get("calibrated_sensor", sd["calibrated_sensor_token"])
    pose = nusc.get("ego_pose", sd["ego_pose_token"])
    return cs, pose

def global_box_to_lidar(box, cs, pose):
    """Transform a Box from global frame to lidar frame (in-place)."""
    box.translate(-np.array(pose["translation"]))
    box.rotate(Quaternion(pose["rotation"]).inverse)
    box.translate(-np.array(cs["translation"]))
    box.rotate(Quaternion(cs["rotation"]).inverse)
    return box

def render_bev_box(ax, box, color, linewidth=2, linestyle="-", alpha=1.0,
                   fill=False, fill_alpha=0.15, zorder=3):
    """Render a single 3-D box in BEV (top-down, XY plane)."""
    corners = box.corners()  # 3×8
    idx = [0, 1, 5, 4, 0]
    xs = corners[0, idx]
    ys = corners[1, idx]
    ax.plot(xs, ys, color=color, linewidth=linewidth, linestyle=linestyle,
            alpha=alpha, zorder=zorder)
    if fill:
        ax.fill(xs, ys, color=color, alpha=fill_alpha, zorder=zorder - 1)
    # heading indicator (front edge)
    fx = corners[0, [0, 1]]
    fy = corners[1, [0, 1]]
    ax.plot(fx, fy, color=color, linewidth=linewidth + 1, linestyle=linestyle,
            alpha=alpha, zorder=zorder + 1)

def get_all_gt_lidar(nusc, sample_token):
    """All GT boxes in lidar frame with detection names (skip None)."""
    s = nusc.get("sample", sample_token)
    cs, pose = _lidar_meta(nusc, sample_token)
    boxes = []
    for ann_tk in s["anns"]:
        ann = nusc.get("sample_annotation", ann_tk)
        det = category_to_detection_name(ann["category_name"])
        if det is None:
            continue
        b = Box(ann["translation"], ann["size"], Quaternion(ann["rotation"]))
        global_box_to_lidar(b, cs, pose)
        b.name = det
        boxes.append(b)
    return boxes

def get_radar_points_lidar(nusc, sample_token, nsweeps=6):
    """Radar points in lidar frame (18×N)."""
    try:
        from data.nuscenes_dataset import RadarPointCloud_v2
    except ImportError:
        return np.zeros((18, 0))
    sample = nusc.get("sample", sample_token)
    radars = ["RADAR_FRONT", "RADAR_FRONT_LEFT", "RADAR_FRONT_RIGHT",
              "RADAR_BACK_LEFT", "RADAR_BACK_RIGHT"]
    pts = np.zeros((18, 0))
    for r in radars:
        if r not in sample["data"]:
            continue
        sd = nusc.get("sample_data", sample["data"][r])
        try:
            pc, _ = RadarPointCloud_v2.from_file_multisweep(
                nusc, sample, sample, sd["channel"], "LIDAR_TOP", nsweeps=nsweeps)
            pts = np.concatenate([pts, pc.points], axis=1)
        except Exception:
            pass
    return pts

# ───────────────────── map background ─────────────────────
# Same approach as visual/plot_bev_comparison_grid.py:draw_map_bg


def _render_road_on_ax(ax, nusc, sample_token, cx, cy, half):
    """Drivable raster in lidar frame via NuScenesMap.get_map_mask."""
    if not HAS_MAP:
        print("  [WARN] nuscenes map-expansion not available; skipping map.")
        return
    try:
        sample = nusc.get("sample", sample_token)
        scene = nusc.get("scene", sample["scene_token"])
        log = nusc.get("log", scene["log_token"])
        location = log["location"]
        nmap = NuScenesMap(dataroot=nusc.dataroot, map_name=location)

        sd = nusc.get("sample_data", sample["data"]["LIDAR_TOP"])
        ep = nusc.get("ego_pose", sd["ego_pose_token"])
        cs_sd = nusc.get("calibrated_sensor", sd["calibrated_sensor_token"])
        ex, ey = ep["translation"][0], ep["translation"][1]
        eyaw = Quaternion(ep["rotation"]).yaw_pitch_roll[0]
        lidar_yaw = Quaternion(cs_sd["rotation"]).yaw_pitch_roll[0]
        total_yaw = eyaw + lidar_yaw

        half_range = float(max(half + max(abs(cx), abs(cy)), 40.0))
        patch_size = half_range * 2.0
        patch_angle_deg = np.degrees(total_yaw)

        mask = nmap.get_map_mask(
            patch_box=(ex, ey, patch_size, patch_size),
            patch_angle=patch_angle_deg,
            layer_names=["drivable_area"],
            canvas_size=(MAP_CANVAS_PX, MAP_CANVAS_PX),
        )
        road = mask[0].astype(bool)
        h, w = road.shape
        rgb = np.full((h, w, 3), BG_NON_ROAD_MAP, dtype=np.float32)
        for c in range(3):
            rgb[:, :, c] = np.where(road, BG_ROAD_MAP[c], BG_NON_ROAD_MAP[c])

        ax.imshow(
            rgb,
            extent=[-half_range, half_range, -half_range, half_range],
            origin="lower",
            zorder=0,
            interpolation="bilinear",
        )
        print(f"  [INFO] Road map (get_map_mask) ok: {location}, half_range={half_range:.1f} m")
    except Exception as e:
        print(f"  [WARN] Road map render failed: {e}")

# ───────────────────── search logic ─────────────────────

def _three_consecutive(nusc, sample_token):
    """Return [t-2, t-1, t] sample tokens or None."""
    s = nusc.get("sample", sample_token)
    if s["prev"] == "":
        return None
    s1 = nusc.get("sample", s["prev"])
    if s1["prev"] == "":
        return None
    return [s1["prev"], s1["token"], s["token"]]

def find_best_vehicle(nusc, all_pred_annos, search_tokens, score_th=0.2):
    """
    Search for a fast-moving vehicle (car/truck/bus) visible in 3 consecutive frames.
    Returns (instance_token, [tok_t-2, tok_t-1, tok_t], displacement_m) or None.
    """
    best = None
    for st in search_tokens:
        toks3 = _three_consecutive(nusc, st)
        if toks3 is None:
            continue
        # instance positions in global frame
        per_frame = []
        for ft in toks3:
            s = nusc.get("sample", ft)
            insts = {}
            for ann_tk in s["anns"]:
                ann = nusc.get("sample_annotation", ann_tk)
                det = category_to_detection_name(ann["category_name"])
                if det not in VEHICLE_CLASSES:
                    continue
                insts[ann["instance_token"]] = np.array(ann["translation"][:2])
            per_frame.append(insts)
        common = set(per_frame[0]) & set(per_frame[1]) & set(per_frame[2])
        for inst in common:
            disp = float(np.linalg.norm(per_frame[2][inst] - per_frame[0][inst]))
            if disp < MIN_DISPLACEMENT:
                continue
            has_pred = toks3[-1] in all_pred_annos and len(all_pred_annos[toks3[-1]]) > 0
            if not has_pred:
                continue
            if best is None or disp > best[2]:
                best = (inst, toks3, disp)
    return best

# ───────────────────── main figure ─────────────────────

def generate_figure(nusc, all_pred_annos, save_dir, score_th=0.2):
    os.makedirs(save_dir, exist_ok=True)

    # ---- build search pool (prefer samples with predictions) ----
    val_tokens = list(all_pred_annos.keys())
    search = val_tokens[:600] if val_tokens else [s["token"] for s in nusc.sample[:300]]

    print("[INFO] Searching for a fast-moving vehicle (3 consecutive frames)...")
    result = find_best_vehicle(nusc, all_pred_annos, search, score_th)
    if result is None:
        print("[ERROR] No suitable vehicle found. Try increasing search range or "
              f"lowering MIN_DISPLACEMENT (currently {MIN_DISPLACEMENT} m). Exiting.")
        return
    target_inst, toks3, displacement = result
    print(f"[INFO] Instance {target_inst[:12]}...  displacement={displacement:.2f} m")
    for i, tk in enumerate(toks3):
        scene = nusc.get("scene", nusc.get("sample", tk)["scene_token"])
        print(f"       frame {i} ({['t-2','t-1','t'][i]}): {tk[:16]}... "
              f"scene={scene['name']}")

    # ---- gather frame meta ----
    frame_meta = []
    for ft in toks3:
        cs, pose = _lidar_meta(nusc, ft)
        ts = nusc.get("sample", ft)["timestamp"]
        frame_meta.append({"token": ft, "cs": cs, "pose": pose, "ts": ts})

    tgt_cs = frame_meta[-1]["cs"]
    tgt_pose = frame_meta[-1]["pose"]

    # ---- target GT in global → ego-comp to frame-t lidar ----
    ego_comp_boxes = []  # len=3, one per frame
    gt_global_centers = []
    for fm in frame_meta:
        s = nusc.get("sample", fm["token"])
        found = False
        for ann_tk in s["anns"]:
            ann = nusc.get("sample_annotation", ann_tk)
            if ann["instance_token"] != target_inst:
                continue
            det = category_to_detection_name(ann["category_name"]) or "car"
            b = Box(ann["translation"], ann["size"], Quaternion(ann["rotation"]))
            b.name = det
            gt_global_centers.append(np.array(ann["translation"][:2]))
            b_lidar = copy.deepcopy(b)
            global_box_to_lidar(b_lidar, tgt_cs, tgt_pose)
            ego_comp_boxes.append(b_lidar)
            found = True
            break
        if not found:
            ego_comp_boxes.append(None)
            gt_global_centers.append(None)

    gt_t = ego_comp_boxes[-1]  # GT at frame t in frame-t lidar (correct position)

    # ---- SPRFusion prediction at frame t ----
    pred_box_t = None
    pred_annos_t = all_pred_annos.get(toks3[-1], [])
    if gt_t is not None and pred_annos_t:
        gt_c2 = gt_t.center[:2]
        best_d = 5.0
        for pa in pred_annos_t:
            if pa.get("detection_score", 0) < score_th:
                continue
            pb = Box(pa["translation"], pa["size"], Quaternion(pa["rotation"]))
            pb.name = pa["detection_name"]
            pb_l = copy.deepcopy(pb)
            global_box_to_lidar(pb_l, tgt_cs, tgt_pose)
            d = float(np.linalg.norm(pb_l.center[:2] - gt_c2))
            if d < best_d:
                best_d = d
                pred_box_t = pb_l
        if pred_box_t is not None:
            print(f"[INFO] Matched prediction  dist_to_gt={best_d:.3f} m")

    # ---- other GT at frame t (context) ----
    all_gt_t = get_all_gt_lidar(nusc, toks3[-1])

    # ---- radar points for background ----
    radar_pts = get_radar_points_lidar(nusc, toks3[-1], nsweeps=6)

    # ---- zoom region ----
    centers = [b.center[:2] for b in ego_comp_boxes if b is not None]
    if pred_box_t is not None:
        centers.append(pred_box_t.center[:2])
    arr = np.array(centers)
    cx = arr[:, 0].mean()
    cy = arr[:, 1].mean()
    span = max(np.ptp(arr[:, 0]), np.ptp(arr[:, 1]))
    half = max(16, span / 2 + 10)

    # ---- timestamps ----
    dt_total = (frame_meta[-1]["ts"] - frame_meta[0]["ts"]) / 1e6
    dt_01 = (frame_meta[1]["ts"] - frame_meta[0]["ts"]) / 1e6
    dt_12 = (frame_meta[2]["ts"] - frame_meta[1]["ts"]) / 1e6

    # ============================================================
    #  PLOT
    # ============================================================
    fig, (ax_ego, ax_ours) = plt.subplots(1, 2, figsize=(22, 10))

    ghost_styles = [
        ((1.0, 0.55, 0.1), 2.8, "--", 0.75, r"$t{-}2$ (ego-comp)"),
        ((1.0, 0.30, 0.0), 2.8, "-.", 0.85, r"$t{-}1$ (ego-comp)"),
    ]

    for ax, is_left in [(ax_ego, True), (ax_ours, False)]:
        ax.set_facecolor("#f7f7f2")

        _render_road_on_ax(ax, nusc, toks3[-1], cx, cy, half)

        if radar_pts.shape[1] > 0:
            rp = radar_pts[:2, :]
            m = (np.abs(rp[0] - cx) < half * 1.2) & (np.abs(rp[1] - cy) < half * 1.2)
            if m.any():
                ax.scatter(rp[0, m], rp[1, m], c="#b8b8b8", s=2, alpha=0.25,
                           zorder=1, rasterized=True)

        for b in all_gt_t:
            if gt_t is not None and np.linalg.norm(b.center[:2] - gt_t.center[:2]) < 1.0:
                continue
            render_bev_box(ax, b, color=(0.82, 0.82, 0.82), linewidth=0.8,
                           linestyle="-", alpha=0.40, zorder=2)

        # ======================= LEFT PANEL =======================
        if is_left:
            for i in range(2):
                ebox = ego_comp_boxes[i]
                if ebox is None:
                    continue
                col, lw, ls, alp, lbl = ghost_styles[i]
                render_bev_box(ax, ebox, color=col, linewidth=lw, linestyle=ls,
                               alpha=alp, fill=True, fill_alpha=0.15, zorder=4 + i)
                off_x, off_y = 2.5, 2.0 + i * 1.5
                ax.text(ebox.center[0] + off_x, ebox.center[1] + off_y,
                        lbl, fontsize=12, fontweight="bold", color=col,
                        ha="left", va="bottom",
                        bbox=dict(boxstyle="round,pad=0.20", fc="white",
                                  ec=col, alpha=0.90, lw=1.2),
                        zorder=10)

            if gt_t is not None:
                render_bev_box(ax, gt_t, color=(0.0, 0.72, 0.0), linewidth=3.2,
                               linestyle="-", fill=True, fill_alpha=0.12, zorder=7)
                ax.text(gt_t.center[0] - 3.0, gt_t.center[1] - 3.0,
                        r"GT ($t$)", fontsize=13, fontweight="bold",
                        color=(0.0, 0.60, 0.0), ha="right", va="top",
                        bbox=dict(boxstyle="round,pad=0.20", fc="white",
                                  ec=(0, 0.60, 0), alpha=0.90, lw=1.2),
                        zorder=10)

            traj_c = [b.center[:2] for b in ego_comp_boxes if b is not None]
            if len(traj_c) >= 2:
                tc = np.array(traj_c)
                ax.plot(tc[:, 0], tc[:, 1], "o-", color="#ff6600",
                        markersize=5, linewidth=1.8, alpha=0.55, zorder=3)
                ax.annotate("", xy=tc[-1], xytext=tc[-2],
                            arrowprops=dict(arrowstyle="-|>", color="#ff6600",
                                            lw=2.0, alpha=0.7),
                            zorder=3)

            if ego_comp_boxes[0] is not None and gt_t is not None:
                c0 = ego_comp_boxes[0].center[:2]
                ct = gt_t.center[:2]
                mid = (c0 + ct) / 2.0
                ghost_d = float(np.linalg.norm(ct - c0))
                ax.annotate("", xy=ct, xytext=c0,
                            arrowprops=dict(arrowstyle="<->", color="#cc0000",
                                            lw=2.0, linestyle="--"),
                            zorder=8)
                ann_x = mid[0] + half * 0.38
                ann_y = mid[1] + half * 0.30
                ax.annotate(
                    "Spatiotemporal Ghosting\n" + r"$\Delta \approx$" + f" {ghost_d:.1f} m",
                    xy=(mid[0], mid[1]),
                    xytext=(ann_x, ann_y),
                    fontsize=12, fontweight="bold", color="#cc0000",
                    arrowprops=dict(arrowstyle="-|>", color="#cc0000",
                                    lw=2.2, connectionstyle="arc3,rad=0.15"),
                    bbox=dict(boxstyle="round,pad=0.35", fc="#fff0f0",
                              ec="#cc0000", alpha=0.92, lw=1.4),
                    ha="center", zorder=11)

            ax.set_title("(a)  Ego-Motion Compensation Only",
                         fontsize=15, fontweight="bold", pad=10)

        # ======================= RIGHT PANEL =======================
        else:
            if gt_t is not None:
                render_bev_box(ax, gt_t, color=(0.0, 0.72, 0.0), linewidth=3.2,
                               linestyle="-", fill=True, fill_alpha=0.12, zorder=7)
                ax.text(gt_t.center[0] - 3.0, gt_t.center[1] - 3.0,
                        r"GT ($t$)", fontsize=13, fontweight="bold",
                        color=(0.0, 0.60, 0.0), ha="right", va="top",
                        bbox=dict(boxstyle="round,pad=0.20", fc="white",
                                  ec=(0, 0.60, 0), alpha=0.90, lw=1.2),
                        zorder=10)

            if pred_box_t is not None:
                render_bev_box(ax, pred_box_t, color=(0.88, 0.08, 0.08),
                               linewidth=3.2, linestyle="-",
                               fill=True, fill_alpha=0.12, zorder=7)
                ax.text(pred_box_t.center[0] + 2.5, pred_box_t.center[1] + 2.5,
                        r"Pred ($t$)", fontsize=13, fontweight="bold",
                        color=(0.80, 0.08, 0.08), ha="left", va="bottom",
                        bbox=dict(boxstyle="round,pad=0.20", fc="white",
                                  ec=(0.80, 0.08, 0.08), alpha=0.90, lw=1.2),
                        zorder=10)

                if gt_t is not None:
                    mid = (gt_t.center[:2] + pred_box_t.center[:2]) / 2.0
                    align_d = float(np.linalg.norm(
                        gt_t.center[:2] - pred_box_t.center[:2]))
                    ann_x = mid[0] + half * 0.38
                    ann_y = mid[1] + half * 0.30
                    ax.annotate(
                        "Aligned  (Ghost-Free)\n"
                        f"Center error = {align_d:.2f} m",
                        xy=(mid[0], mid[1]),
                        xytext=(ann_x, ann_y),
                        fontsize=12, fontweight="bold", color="#006600",
                        arrowprops=dict(arrowstyle="-|>", color="#006600",
                                        lw=2.2, connectionstyle="arc3,rad=-0.15"),
                        bbox=dict(boxstyle="round,pad=0.35", fc="#f0fff0",
                                  ec="#006600", alpha=0.92, lw=1.4),
                        ha="center", zorder=11)

            for i in range(2):
                eb = ego_comp_boxes[i]
                if eb is None:
                    continue
                render_bev_box(ax, eb, color=(0.82, 0.82, 0.82), linewidth=1.2,
                               linestyle=":", alpha=0.45, zorder=2)
                lbl = [r"$t{-}2$ ghost", r"$t{-}1$ ghost"][i]
                ax.text(eb.center[0], eb.center[1] + 2.5,
                        lbl, fontsize=9, color="#aaaaaa", ha="center",
                        fontstyle="italic", zorder=10)

            ax.set_title("(b)  SPRFusion Temporal Alignment (Ours)",
                         fontsize=15, fontweight="bold", pad=10)

        # ---- common axis settings ----
        ax.plot(0, 0, marker="^", color="#1565C0", markersize=11,
                markeredgewidth=2, markeredgecolor="white", zorder=12)
        ax.text(0, -2.0, "Ego", fontsize=9, ha="center", color="#1565C0",
                fontweight="bold", zorder=12)

        ax.set_xlim(cx - half, cx + half)
        ax.set_ylim(cy - half, cy + half)
        ax.set_aspect("equal")
        ax.set_xlabel("X  (m)", fontsize=12)
        ax.set_ylabel("Y  (m)", fontsize=12)
        ax.grid(True, alpha=0.20, linewidth=0.4, color="gray")

    # ---- suptitle ----
    scene = nusc.get("scene", nusc.get("sample", toks3[-1])["scene_token"])
    desc = scene.get("description", "")[:90]
    fig.suptitle(
        "Temporal Feature Alignment in BEV:  Ego-Motion Compensation  vs.  SPRFusion\n"
        f"3 consecutive keyframes,  "
        r"$\Delta t$ = " + f"{dt_01:.2f}s + {dt_12:.2f}s = {dt_total:.2f}s,  "
        f"vehicle displacement = {displacement:.1f} m\n"
        f"Scene: {desc}",
        fontsize=13, fontweight="bold", y=1.04)

    # ---- legend ----
    legend_elems = [
        Line2D([0], [0], color=(0, 0.72, 0), lw=3,
               label=r"Ground Truth (frame $t$)"),
        Line2D([0], [0], color=(0.88, 0.08, 0.08), lw=3,
               label=r"SPRFusion Pred (frame $t$)"),
        Line2D([0], [0], color=(1.0, 0.55, 0.1), lw=2.5, ls="--",
               label=r"Ego-comp ghost ($t{-}2$)"),
        Line2D([0], [0], color=(1.0, 0.30, 0.0), lw=2.5, ls="-.",
               label=r"Ego-comp ghost ($t{-}1$)"),
        Line2D([0], [0], color=(0.82, 0.82, 0.82), lw=1.0,
               label="Other objects (context)"),
        Line2D([0], [0], marker="^", color="#1565C0", lw=0, markersize=9,
               label="Ego vehicle"),
    ]
    fig.legend(handles=legend_elems, loc="lower center", ncol=3, fontsize=10,
               bbox_to_anchor=(0.5, -0.04), frameon=True, fancybox=True,
               edgecolor="#cccccc")

    plt.tight_layout(rect=[0, 0.04, 1, 0.94])

    save_path = os.path.join(save_dir, "fig3a_ego_vs_sprfusion_temporal.png")
    fig.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"\n[SAVED] {save_path}")
    print(f"        size = {os.path.getsize(save_path)/1024/1024:.1f} MB")
    return save_path

# ───────────────────── CLI ─────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Figure 3(a): Ego-motion ghosting vs SPRFusion alignment")
    parser.add_argument("--dataroot", type=str,
                        default=os.path.join(PROJECT_ROOT, "data/nuscenes"))
    parser.add_argument("--results_json", type=str,
                        default=os.path.join(PROJECT_ROOT,
                                             "submission/pts_bbox/results_nusc.json"))
    parser.add_argument("--save_dir", type=str,
                        default=os.path.join(PROJECT_ROOT, "visual"))
    parser.add_argument("--score_th", type=float, default=0.20)
    args = parser.parse_args()

    print("=" * 60)
    print("  Figure 3(a): Ego-Motion Compensation  vs.  SPRFusion")
    print("=" * 60)

    nusc = NuScenes(version="v1.0-trainval", dataroot=args.dataroot, verbose=False)
    print(f"[INFO] Loaded {len(nusc.sample)} samples")

    all_pred_annos = {}
    if os.path.exists(args.results_json):
        print(f"[INFO] Loading predictions from {args.results_json}")
        with open(args.results_json, "r") as f:
            data = json.load(f)
        all_pred_annos = data.get("results", {})
        print(f"[INFO] Predictions for {len(all_pred_annos)} samples")
    else:
        print(f"[WARN] {args.results_json} not found; GT-only mode")

    generate_figure(nusc, all_pred_annos, args.save_dir, score_th=args.score_th)

    print("\nDone.")

if __name__ == "__main__":
    main()