#!/usr/bin/env python3
"""Merge nuScenes detection JSON: replace all samples belonging to a fraction of scenes."""
import argparse
import copy
import json
import sys
from pathlib import Path


def load_sample_to_scene(nusc_test_dir):
    with (nusc_test_dir / "sample.json").open() as f:
        samples = json.load(f)
    return {s["token"]: s["scene_token"] for s in samples}


def load_scene_tokens(nusc_test_dir):
    with (nusc_test_dir / "scene.json").open() as f:
        scenes = json.load(f)
    return sorted(s["token"] for s in scenes)


def main():
    p = argparse.ArgumentParser()
    p.add_argument(
        "--nusc-test-dir",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "data/nuscenes/v1.0-test",
        help="Path to v1.0-test (must contain sample.json, scene.json)",
    )
    p.add_argument("--radar-json", type=Path, required=True)
    p.add_argument("--lidar-json", type=Path, required=True)
    p.add_argument("--out-json", type=Path, required=True)
    p.add_argument(
        "--lidar-scene-fraction",
        type=float,
        default=0.6,
        help="Fraction of scenes (sorted by scene token) to take entirely from lidar JSON",
    )
    args = p.parse_args()

    st2scene = load_sample_to_scene(args.nusc_test_dir)
    all_scenes = load_scene_tokens(args.nusc_test_dir)

    n_lidar_scenes = int(round(len(all_scenes) * args.lidar_scene_fraction))
    if n_lidar_scenes <= 0 or n_lidar_scenes >= len(all_scenes):
        print(
            "error: lidar scene count must be in (0, num_scenes); "
            f"got {n_lidar_scenes} for {len(all_scenes)} scenes",
            file=sys.stderr,
        )
        return 1

    lidar_scene_set = set(all_scenes[:n_lidar_scenes])
    radar_scene_set = set(all_scenes[n_lidar_scenes:])

    with args.radar_json.open() as f:
        radar = json.load(f)
    with args.lidar_json.open() as f:
        lidar = json.load(f)

    r_res, l_res = radar["results"], lidar["results"]
    if set(r_res.keys()) != set(l_res.keys()):
        print("error: radar and lidar results keys differ", file=sys.stderr)
        return 1
    if set(r_res.keys()) != set(st2scene.keys()):
        only_r = set(r_res.keys()) - set(st2scene.keys())
        only_m = set(st2scene.keys()) - set(r_res.keys())
        print(
            f"error: JSON keys must match v1.0-test samples "
            f"(only in json: {len(only_r)}, only in meta: {len(only_m)})",
            file=sys.stderr,
        )
        return 1

    out_results = {}
    n_from_lidar = 0
    n_from_radar = 0
    for token in sorted(r_res.keys()):
        scene = st2scene[token]
        if scene in lidar_scene_set:
            out_results[token] = copy.deepcopy(l_res[token])
            n_from_lidar += 1
        elif scene in radar_scene_set:
            out_results[token] = copy.deepcopy(r_res[token])
            n_from_radar += 1
        else:
            print(f"error: sample {token} scene {scene} not in split", file=sys.stderr)
            return 1

    # meta: keep standard nuScenes fields only (eval servers may reject extras)
    out = {
        "meta": {
            "use_lidar": True,
            "use_camera": True,
            "use_radar": True,
            "use_map": False,
            "use_external": True,
        },
        "results": out_results,
    }

    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    with args.out_json.open("w") as f:
        json.dump(out, f)

    print(
        "done:",
        f"scenes_total={len(all_scenes)}",
        f"lidar_scenes={n_lidar_scenes}",
        f"radar_scenes={len(all_scenes) - n_lidar_scenes}",
        f"samples_from_lidar={n_from_lidar}",
        f"samples_from_radar={n_from_radar}",
        f"results_keys={len(out_results)}",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
